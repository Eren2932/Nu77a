package club.nuva.app.ui

/** Preview is a UI destination, never an authenticated session. */
internal enum class RootDestination { Welcome, Server, Auth, Home, Preview }

internal fun rootDestination(
    preview: Boolean,
    welcomeSeen: Boolean,
    hasServer: Boolean,
    hasSession: Boolean,
    switchingServer: Boolean,
): RootDestination = when {
    preview -> RootDestination.Preview
    !welcomeSeen && !hasSession -> RootDestination.Welcome
    !hasServer || switchingServer -> RootDestination.Server
    hasSession -> RootDestination.Home
    else -> RootDestination.Auth
}

/** Preview-first only applies to a pristine install: never hides a real server or account. */
internal fun startsInPreview(previewFirst: Boolean, hasServer: Boolean, hasSession: Boolean): Boolean =
    previewFirst && !hasServer && !hasSession
