#!/usr/bin/env python3
"""Source-level regression checks only. Does NOT compile Kotlin or execute Android."""
from pathlib import Path
import itertools
import json
import re
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
src = root / 'android/app/src/main/kotlin/club/nuva/app'
subprocess.run([sys.executable, str(root / 'scripts/check-ui-resources.py')], check=True)
selector = (src / 'ui/RootDestination.kt').read_text()
rules = re.findall(r'^    (.+?) -> RootDestination\.(\w+)$', selector, re.M)
assert len(rules) == 5
for values in itertools.product([False, True], repeat=5):
    preview, welcomeSeen, hasServer, hasSession, switchingServer = values
    env = dict(zip(['preview','welcomeSeen','hasServer','hasSession','switchingServer'], values))
    result = None
    for expr, target in rules:
        # Only evaluate the tiny checked boolean grammar of the destination selector.
        assert re.fullmatch(r'[A-Za-z! &|]+', expr)
        if expr == 'else' or eval(expr.replace('!', ' not ').replace('&&',' and ').replace('||',' or '), {'__builtins__': {}}, env):
            result = target
            break
    expected = ('Preview' if preview else 'Welcome' if not welcomeSeen and not hasSession
                else 'Server' if not hasServer or switchingServer else 'Home' if hasSession else 'Auth')
    assert result == expected, (values, result, expected)
print('PASS: source-extracted root selector, all 32 boolean combinations (not JVM execution)')

fixtures = (src / 'ui/preview/PreviewFixtures.kt').read_text()
messages = re.findall(r'message\("([^"]+)", (true|false), ("(?:\\.|[^"\\])*"), (\d+)\)', fixtures)
assert len(messages) == 15
assert len({m[0] for m in messages}) == len(messages)
chats = re.findall(r'Chat\("([^"]+)", "([^"]+)", "([^"]+)"', fixtures)
assert len(chats) == 4 and len({c[0] for c in chats}) == 4 and len({c[2] for c in chats}) == 4
assert {m[1] for m in messages} == {'true','false'}
assert any('\n' in json.loads(m[2]) for m in messages)
for prefix in ['design','layout','notes']:
    ages = [int(m[3]) for m in messages if m[0].startswith(prefix)]
    assert ages == sorted(ages, reverse=True)
assert sum(m[1] == 'false' for m in messages if m[0].startswith('design')) >= 2
print('PASS: 4 fixture chats, 15 messages, unique IDs, chronological order, both authors and multiline sample')

preview = (src / 'ui/preview/PreviewSession.kt').read_text()
assert 'ChatDatabase(context, name = null)' in preview
for forbidden in ['SessionStore', 'ServerStore', 'NuvaApi', 'RealtimeClient', 'authRepository', 'sessionStore', 'serverStore']:
    assert forbidden not in preview
shell = (src / 'ui/shell/NuvaShell.kt').read_text()
assert 'preview?.chats ?: ServiceLocator.chatDrafts' in shell
assert re.search(r'if \(preview != null\) \{\s*//[^\n]*\n\s*PreviewDiagnosticsScreen\(.*?\n\s*\} else \{\s*val vm: HomeViewModel', shell)
assert 'ChatViewModel(id, chatStore,' in shell and 'NewChatScreen(chatStore,' in shell
editor = (src / 'ui/profile/EditProfileScreen.kt').read_text()
assert 'imageUrl = if (preview != null) null else' in editor
profile = (src / 'ui/profile/ProfileScreen.kt').read_text()
assert 'if (preview != null) {\n                    onExitPreview()' in profile
app = (src / 'ui/NuvaApp.kt').read_text()
assert 'serverViewModel.cancelPending()' in app
assert 'authViewModel.cancelPending()' in app
assert 'ServiceLocator.realtime.disconnect()' in app
assert 'startsInPreview(BuildConfig.PREVIEW_FIRST, server != null, session != null)' in app
gradle = (root / 'android/app/build.gradle.kts').read_text()
assert re.search(r'debug \{.*?"PREVIEW_FIRST", \(previewFirstOverride \?: true\)', gradle, re.S)
assert re.search(r'release \{.*?"PREVIEW_FIRST", \(previewFirstOverride \?: false\)', gradle, re.S)
print('PASS: preview-first default true in debug, false in release, pristine-install only')
print('PASS: static isolation guards, passive diagnostics branch, disabled remote avatar, cancellable entry')
print('NOT RUN: Kotlin/Compose compilation, JVM tests, instrumentation, APK install, live network capture')
