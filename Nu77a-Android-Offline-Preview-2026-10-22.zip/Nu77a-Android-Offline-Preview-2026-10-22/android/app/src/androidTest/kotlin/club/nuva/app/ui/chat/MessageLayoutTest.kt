package club.nuva.app.ui.chat

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import club.nuva.app.ui.chat.layout.TimelineRow
import club.nuva.app.ui.theme.NuvaTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Requires an emulator/device. These assert rendered bounds, not character-count estimates. */
class MessageLayoutTest {
    @get:Rule val compose = createComposeRule()
    private fun show(text: String, mine: Boolean = true, fontScale: Float = 1f, dark: Boolean = true) {
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, fontScale)) {
                NuvaTheme(darkTheme = dark) {
                    Box(Modifier.width(320.dp)) {
                        MessageBubble(
                            ChatDraftStore.Message("sample", if (mine) "me" else "peer", text, 1_792_582_200_000L, ChatDraftStore.Delivery.Sent),
                            TimelineRow.Message("sample", false, false), 256.dp, {}, {},
                        )
                    }
                }
            }
        }
    }
    private fun bounds(tag: String): Rect = compose.onNodeWithTag(tag, useUnmergedTree = true).fetchSemanticsNode().boundsInRoot
    private fun assertContainedAndNonOverlapping() {
        val body = bounds("body:sample")
        val meta = bounds("metadata:sample")
        val bubble = bounds("bubble:sample")
        assertTrue(meta.left >= bubble.left && meta.right <= bubble.right + 1f)
        assertTrue(meta.top >= bubble.top && meta.bottom <= bubble.bottom + 1f)
        // Single-line or forced-row fixtures only: multiline text has a rectangular
        // semantics box even when its last visual line leaves room for metadata.
        assertTrue(meta.top >= body.bottom - 1f || meta.left >= body.right - 1f)
    }
    @Test fun shortOutgoingUsesInlineTime() {
        show("Привет")
        assertContainedAndNonOverlapping()
        assertTrue(bounds("metadata:sample").top < bounds("body:sample").bottom)
    }
    @Test fun rtlUsesOwnMetadataRow() {
        show("مرحبا بالعالم", mine = false)
        assertContainedAndNonOverlapping()
        assertTrue(bounds("metadata:sample").top >= bounds("body:sample").bottom - 1f)
    }
    @Test fun largeFontAndEmojiDoNotOverlapMetadata() {
        show("🙂", fontScale = 2f)
        assertContainedAndNonOverlapping()
    }
    @Test fun lightIncomingHasSameGeometry() {
        show("Hi", mine = false, dark = false)
        assertContainedAndNonOverlapping()
    }
    @Test fun blankComposerCannotSend() {
        compose.setContent { NuvaTheme(darkTheme = true) { MessageComposer("  ", {}, {}, false, true) } }
        compose.onNodeWithTag("composer-send").assertIsNotEnabled()
    }
    @Test fun imeSendUsesLatestTextAndDoesNotSendTwice() {
        val text = mutableStateOf("")
        val sent = mutableListOf<String>()
        compose.setContent {
            NuvaTheme(darkTheme = true) {
                MessageComposer(text.value, { text.value = it }, { sent += text.value; text.value = "" }, true, true)
            }
        }
        compose.onNodeWithTag("composer-input").performTextInput("Привет")
        compose.onNodeWithTag("composer-input").performImeAction()
        compose.runOnIdle { assertEquals(listOf("Привет"), sent); assertEquals("", text.value) }
    }
}
