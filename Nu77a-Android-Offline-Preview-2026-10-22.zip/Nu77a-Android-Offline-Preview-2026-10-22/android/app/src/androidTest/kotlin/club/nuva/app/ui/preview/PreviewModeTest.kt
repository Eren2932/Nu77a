package club.nuva.app.ui.preview

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.test.platform.app.InstrumentationRegistry
import club.nuva.app.R
import club.nuva.app.di.ServiceLocator
import club.nuva.app.ui.NuvaApp
import club.nuva.app.ui.home.PreviewDiagnosticsScreen
import club.nuva.app.ui.shell.NuvaShell
import club.nuva.app.ui.theme.NuvaTheme
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Rule
import org.junit.Test

/** Run on a clean emulator. Never clears a pre-existing account to make a test pass. */
class PreviewModeTest {
    @get:Rule val compose = createComposeRule()
    private fun label(id: Int) = InstrumentationRegistry.getInstrumentation().targetContext.getString(id)

    @Test fun serverCanBeSkippedAndExitDoesNotCreateSessionOrModifyServer() {
        assumeTrue(ServiceLocator.authRepository.session.value == null)
        assumeTrue(ServiceLocator.serverRepository.baseUrl.value == null)
        ServiceLocator.uiPrefs.setWelcomeSeen()
        compose.setContent { NuvaTheme(darkTheme = true) { NuvaApp() } }
        compose.onNodeWithTag("preview-enter").performScrollTo().performClick()
        compose.onNodeWithTag("preview-exit").assertIsDisplayed()
        compose.waitUntil(10_000) { ServiceLocator.previewSession.chats.loaded.value }
        compose.runOnIdle {
            assertNull(ServiceLocator.authRepository.session.value)
            assertNull(ServiceLocator.serverRepository.baseUrl.value)
            assertNotSame(ServiceLocator.chatDrafts, ServiceLocator.previewSession.chats)
        }
        compose.onNodeWithTag("preview-exit").performClick()
        compose.onNodeWithTag("preview-exit").assertDoesNotExist()
        compose.onNodeWithTag("preview-enter").assertExists()
    }

    @Test fun demoNavigationSurvivesSavedStateRestoration() {
        assumeTrue(ServiceLocator.authRepository.session.value == null)
        assumeTrue(ServiceLocator.serverRepository.baseUrl.value == null)
        ServiceLocator.uiPrefs.setWelcomeSeen()
        val restoration = StateRestorationTester(compose)
        restoration.setContent { NuvaTheme(darkTheme = true) { NuvaApp() } }
        compose.onNodeWithTag("preview-enter").performScrollTo().performClick()
        compose.onNodeWithTag("preview-exit").assertIsDisplayed()
        restoration.emulateSavedInstanceStateRestore()
        compose.onNodeWithTag("preview-exit").assertIsDisplayed()
        compose.runOnIdle { assertNull(ServiceLocator.authRepository.session.value) }
    }

    @Test fun drawerOpensContactsProfileEditorAndSettingsWithoutAccount() {
        compose.setContent {
            NuvaTheme(darkTheme = true) {
                CompositionLocalProvider(LocalPreviewSession provides ServiceLocator.previewSession) {
                    NuvaShell(onSwitchServer = {})
                }
            }
        }
        compose.waitUntil(10_000) { ServiceLocator.previewSession.chats.loaded.value }
        compose.onNodeWithContentDescription(label(R.string.open_menu)).performClick()
        compose.onNodeWithTag("preview-route-new_chat").performClick()
        compose.onNodeWithContentDescription("Back").performClick()
        compose.onNodeWithContentDescription(label(R.string.open_menu)).performClick()
        compose.onNodeWithTag("preview-route-profile").performClick()
        compose.onNodeWithTag("profile-edit").performClick()
        compose.onNodeWithText("Save changes").performScrollTo().assertIsEnabled()
        compose.onNodeWithContentDescription("Back").performClick()
        compose.onNodeWithContentDescription(label(R.string.settings)).performClick()
        compose.onNodeWithText(label(R.string.preview_connect)).performScrollTo().assertIsDisplayed()
    }

    @Test fun sampleChatCanSendLocallyWithoutTouchingRealHistory() {
        val realStore = ServiceLocator.chatDrafts
        compose.waitUntil(10_000) { realStore.loaded.value }
        val before = realStore.conversations.value
        compose.setContent {
            NuvaTheme(darkTheme = true) {
                CompositionLocalProvider(LocalPreviewSession provides ServiceLocator.previewSession) {
                    NuvaShell(onSwitchServer = {})
                }
            }
        }
        compose.waitUntil(10_000) { ServiceLocator.previewSession.chats.loaded.value }
        compose.onNodeWithText("Дизайн Nu77a").performClick()
        compose.onNodeWithTag("composer-input").performTextInput("Offline smoke test")
        compose.onNodeWithTag("composer-send").performClick()
        compose.waitUntil(10_000) {
            ServiceLocator.previewSession.chats.conversation("preview-design")?.messages
                ?.any { it.text == "Offline smoke test" && it.delivery == club.nuva.app.ui.chat.ChatDraftStore.Delivery.Sent } == true
        }
        compose.runOnIdle { assertEquals(before, realStore.conversations.value) }
        compose.onNodeWithTag("composer-input").assertTextEquals("")
    }

    @Test fun previewDiagnosticsCannotRefreshOrSendEcho() {
        compose.setContent {
            NuvaTheme(darkTheme = true) {
                CompositionLocalProvider(LocalPreviewSession provides ServiceLocator.previewSession) {
                    PreviewDiagnosticsScreen(onBack = {})
                }
            }
        }
        compose.onNodeWithTag("diagnostics-refresh").assertIsNotEnabled()
        compose.onNodeWithTag("diagnostics-echo").performScrollTo().assertIsNotEnabled()
        compose.onNodeWithText(label(R.string.preview_network_disabled)).performScrollTo().assertIsDisplayed()
    }
}
