package club.nuva.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.CompositionLocalProvider
import club.nuva.app.ui.preview.LocalPreviewSession
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import club.nuva.app.di.ServiceLocator
import club.nuva.app.ui.auth.AuthScreen
import club.nuva.app.ui.auth.AuthViewModel
import club.nuva.app.ui.server.ServerScreen
import club.nuva.app.ui.server.ServerViewModel
import club.nuva.app.ui.shell.NuvaShell
import club.nuva.app.ui.onboarding.WelcomeScreen
import club.nuva.app.ui.theme.NuvaTheme
import club.nuva.app.util.ServerUrl

/** Real sign-in remains gated; preview is an explicit, isolated UI-only destination. */
@Composable
fun NuvaApp() {
    val server by ServiceLocator.serverRepository.baseUrl.collectAsStateWithLifecycle()
    val session by ServiceLocator.authRepository.session.collectAsStateWithLifecycle()

    // Set only when the user asks to switch servers while one is configured.
    var switchingServer by rememberSaveable { mutableStateOf(false) }

    val prefs by ServiceLocator.uiPrefs.state.collectAsStateWithLifecycle()

    // Construction is passive. Keep both references here so one Skip cancels
    // either form, including an auth request left while switching servers.
    val serverViewModel: ServerViewModel = viewModel(
        // Keep the successful result while baseUrl changes during connectTo.
        key = "server-picker",
        factory = viewModelFactory { initializer { ServerViewModel(ServiceLocator.serverRepository) } },
    )
    val authViewModel: AuthViewModel = viewModel(
        key = "auth-${server.orEmpty()}",
        factory = viewModelFactory { initializer { AuthViewModel(ServiceLocator.authRepository) } },
    )

    var previewMode by rememberSaveable { mutableStateOf(false) }
    val enterPreview: () -> Unit = {
        serverViewModel.cancelPending()
        authViewModel.cancelPending()
        ServiceLocator.realtime.disconnect()
        ServiceLocator.uiPrefs.setWelcomeSeen()
        previewMode = true
    }
    val exitPreview: () -> Unit = { previewMode = false }
    val openServerPicker: () -> Unit = {
        authViewModel.cancelPending()
        serverViewModel.resetForPicker()
        previewMode = false
        switchingServer = true
    }
    val destination = rootDestination(previewMode, prefs.welcomeSeen,
        server != null, session != null, switchingServer)

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = NuvaTheme.palette.canvas,
    ) {
        Crossfade(
            targetState = destination,
            animationSpec = tween(220),
            label = "root",
        ) { current ->
            when (current) {
                RootDestination.Welcome -> {
                    WelcomeScreen(onDone = { ServiceLocator.uiPrefs.setWelcomeSeen() }, onPreview = enterPreview)
                }

                RootDestination.Server -> {
                    ServerScreen(
                        viewModel = serverViewModel,
                        onConnected = { switchingServer = false },
                        onPreview = enterPreview,
                        onCancel = if (server != null) {
                            { serverViewModel.cancelPending(); switchingServer = false }
                        } else {
                            null
                        },
                    )
                }

                RootDestination.Auth -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        AuthScreen(viewModel = authViewModel, modifier = Modifier.weight(1f), onPreview = enterPreview)
                        ServerFooter(
                            host = ServerUrl.hostOf(server.orEmpty()),
                            onChange = openServerPicker,
                            modifier = Modifier
                                .navigationBarsPadding()
                                .padding(bottom = 12.dp),
                        )
                    }
                }

                RootDestination.Preview -> {
                    CompositionLocalProvider(LocalPreviewSession provides ServiceLocator.previewSession) {
                        NuvaShell(
                            onSwitchServer = openServerPicker,
                            onExitPreview = exitPreview,
                        )
                    }
                }

                RootDestination.Home -> {
                    NuvaShell(onSwitchServer = openServerPicker)
                }
            }
        }
    }
}


/** Always visible on the sign-in screen: you should never wonder who you are trusting. */
@Composable
private fun ServerFooter(
    host: String,
    onChange: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        TextButton(onClick = onChange) {
            Text(
                text = "Server: $host  ·  change",
                style = MaterialTheme.typography.labelMedium,
                color = NuvaTheme.palette.textMuted,
            )
        }
    }
}
