package club.nuva.app.ui.chat

import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection

/** Physical left/right, deliberately independent of the device's UI direction. */
internal class BubbleShape(
    private val mine: Boolean,
    private val joinedAbove: Boolean,
    private val joinedBelow: Boolean,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val radius = with(density) { ChatMetrics.bubbleRadius.toPx() }.coerceAtMost(size.height / 2)
        val join = with(density) { ChatMetrics.joinedRadius.toPx() }.coerceAtMost(radius)
        val tail = with(density) { ChatMetrics.tailWidth.toPx() }.coerceAtMost(size.width / 4)
        val left = tail
        val right = size.width
        val bottom = size.height
        val nearTop = if (joinedAbove) join else radius
        val nearBottom = if (joinedBelow) join else radius
        // Construct an incoming outline, reflect its coordinates for outgoing messages.
        fun x(value: Float) = if (mine) size.width - value else value
        val path = Path().apply {
            moveTo(x(left + nearTop), 0f)
            lineTo(x(right - radius), 0f)
            quadraticBezierTo(x(right), 0f, x(right), radius)
            lineTo(x(right), bottom - radius)
            quadraticBezierTo(x(right), bottom, x(right - radius), bottom)
            lineTo(x(left + nearBottom), bottom)
            if (joinedBelow) {
                quadraticBezierTo(x(left), bottom, x(left), bottom - nearBottom)
            } else {
                cubicTo(x(left + tail / 2), bottom, x(tail / 3), bottom, x(0f), bottom)
                quadraticBezierTo(x(left), bottom - tail / 2, x(left), bottom - radius)
            }
            lineTo(x(left), nearTop)
            quadraticBezierTo(x(left), 0f, x(left + nearTop), 0f)
            close()
        }
        return Outline.Generic(path)
    }
}
