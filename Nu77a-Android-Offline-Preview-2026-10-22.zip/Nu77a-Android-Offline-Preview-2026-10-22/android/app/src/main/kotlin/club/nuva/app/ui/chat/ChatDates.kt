package club.nuva.app.ui.chat

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

internal fun clockLabel(millis: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(millis))

internal fun dayLabel(
    millis: Long,
    today: String,
    yesterday: String,
    nowMillis: Long = System.currentTimeMillis(),
    timeZone: TimeZone = TimeZone.getDefault(),
    locale: Locale = Locale.getDefault(),
): String {
    val now = Calendar.getInstance(timeZone).apply { timeInMillis = nowMillis }
    val then = Calendar.getInstance(timeZone).apply { timeInMillis = millis }
    fun sameDay(a: Calendar, b: Calendar) = a.get(Calendar.ERA) == b.get(Calendar.ERA) &&
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (sameDay(now, then)) return today
    now.add(Calendar.DAY_OF_YEAR, -1) // Jan 1 and DST are calendar operations, not 24-hour subtraction.
    if (sameDay(now, then)) return yesterday
    return DateFormat.getDateInstance(DateFormat.MEDIUM, locale).apply { this.timeZone = timeZone }.format(Date(millis))
}
