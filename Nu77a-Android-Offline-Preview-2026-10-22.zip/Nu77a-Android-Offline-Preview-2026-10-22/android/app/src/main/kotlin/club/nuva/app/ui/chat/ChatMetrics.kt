package club.nuva.app.ui.chat

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.ui.unit.dp

/** See docs/UI-REDESIGN.md: source-observed values vs Nuva adaptation are explicitly separated. */
internal object ChatMetrics {
    val unreadRowHeight = 40.dp
    val unreadStripeHeight = 27.dp
    val unreadStripeTop = 7.dp
    val listGutter = 8.dp
    val joinedGap = 2.dp
    val groupGap = 6.dp
    val bubbleRadius = 12.dp
    val joinedRadius = 5.dp
    val tailWidth = 6.dp
    val bottomSlop = 24.dp
    val horizontalPadding = 11.dp
    val verticalPadding = 6.dp
    val metadataGap = 6.dp
    val oppositeGutter = 48.dp
    const val motionMillis = 250
    val motionEasing = CubicBezierEasing(0.19919473f, 0.010644531f, 0.27920938f, 0.9102539f)
}
