package club.nuva.app.ui.chat

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import club.nuva.app.R
import club.nuva.app.ui.chat.layout.ChatTimeline
import club.nuva.app.ui.chat.layout.TimelineMessage
import club.nuva.app.ui.chat.layout.TimelineRow
import club.nuva.app.ui.design.NuvaAvatar
import club.nuva.app.ui.design.NuvaRow
import club.nuva.app.ui.theme.NuvaTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    sendOnEnter: Boolean = false,
) {
    val p = NuvaTheme.palette
    val conversation by viewModel.conversation.collectAsStateWithLifecycle()
    val loaded by viewModel.loaded.collectAsStateWithLifecycle()
    val draft by viewModel.draft.collectAsStateWithLifecycle()
    val firstUnread by viewModel.firstUnreadId.collectAsStateWithLifecycle()
    val unreadReady by viewModel.unreadReady.collectAsStateWithLifecycle()
    val messages = remember(conversation?.messages) { conversation?.messages.orEmpty().sortedBy { it.sentAtMillis } }
    val rows = remember(messages, firstUnread) {
        ChatTimeline.build(messages.map { TimelineMessage(it.id, it.authorId, it.sentAtMillis) }, firstUnread)
    }
    val byId = remember(messages) { messages.associateBy { it.id } }
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var menu by remember { mutableStateOf(false) }
    var profile by rememberSaveable { mutableStateOf(false) }
    var selectedMessage by remember { mutableStateOf<ChatDraftStore.Message?>(null) }
    var positioned by rememberSaveable { mutableStateOf(false) }
    var followLatest by rememberSaveable { mutableStateOf(true) }
    var lastMessageId by rememberSaveable { mutableStateOf<String?>(null) }
    var initialIds by remember { mutableStateOf<Set<String>?>(null) }
    var resumed by remember { mutableStateOf(false) }
    val currentLatest by rememberUpdatedState(messages.lastOrNull()?.id)
    val currentPositioned by rememberUpdatedState(positioned)
    val unreadHeightPx = with(LocalDensity.current) { ChatMetrics.unreadRowHeight.roundToPx() }
    val bottomSlopPx = with(LocalDensity.current) { ChatMetrics.bottomSlop.roundToPx() }
    val atBottom by remember(list, bottomSlopPx) {
        derivedStateOf { list.firstVisibleItemIndex == 0 && list.firstVisibleItemScrollOffset <= bottomSlopPx }
    }

    LifecycleResumeEffect(Unit) {
        resumed = true
        onPauseOrDispose { resumed = false }
    }
    LaunchedEffect(loaded, conversation?.id) {
        if (loaded && conversation != null && initialIds == null) initialIds = messages.mapTo(mutableSetOf()) { it.id }
    }
    LaunchedEffect(loaded, conversation?.id, unreadReady) {
        if (loaded && unreadReady && conversation != null && !positioned) {
            initialIds = messages.mapTo(mutableSetOf()) { it.id }
            val anchor = rows.indexOfFirst { it is TimelineRow.Unread }.coerceAtLeast(0)
            if (messages.isNotEmpty()) {
                val viewportHeight = snapshotFlow { list.layoutInfo.viewportSize.height }.first { it > 0 }
                // reverseLayout places index at the BOTTOM. A negative offset puts the
                // divider near the TOP, with the unread messages below it (not offscreen).
                val offset = if (anchor > 0) -(viewportHeight - unreadHeightPx).coerceAtLeast(0) else 0
                list.scrollToItem(anchor, offset)
            }
            followLatest = anchor == 0
            lastMessageId = messages.lastOrNull()?.id
            positioned = true
        }
    }
    LaunchedEffect(list, bottomSlopPx) {
        // Insertions can change visible indices. Only actual scroll gestures/animations change follow mode.
        snapshotFlow { Triple(list.isScrollInProgress, list.firstVisibleItemIndex, list.firstVisibleItemScrollOffset) }
            .distinctUntilChanged().collect { (scrolling, index, offset) ->
                if (scrolling) followLatest = index == 0 && offset <= bottomSlopPx
            }
    }
    LaunchedEffect(currentLatest, positioned) {
        if (!positioned) return@LaunchedEffect
        val latest = messages.lastOrNull() ?: return@LaunchedEffect
        if (lastMessageId != latest.id) {
            if (latest.mine || followLatest) {
                list.animateScrollToItem(0)
                followLatest = true
            }
            lastMessageId = latest.id
        }
    }
    LaunchedEffect(list, resumed, positioned, currentLatest, conversation?.unread) {
        if (!resumed || !positioned) return@LaunchedEffect
        snapshotFlow {
            val latestKey = currentLatest?.let { "message:$it" }
            val info = list.layoutInfo
            currentPositioned && latestKey != null && !list.isScrollInProgress && info.visibleItemsInfo.any {
                it.key == latestKey && it.offset < info.viewportEndOffset && it.offset + it.size > info.viewportStartOffset
            }
        }.distinctUntilChanged().collect { if (it) viewModel.onLatestVisible() }
    }

    Column(modifier.fillMaxSize().background(p.canvas).imePadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(p.surface).height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = p.text) }
            Row(
                Modifier.weight(1f).clickable(enabled = conversation != null) { profile = true },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NuvaAvatar(
                    name = conversation?.peer?.displayName ?: "?", seed = conversation?.peer?.id.orEmpty(),
                    size = 42.dp, imageUrl = conversation?.peer?.avatarUrl?.takeIf { it.isNotBlank() },
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(conversation?.peer?.displayName ?: stringResource(R.string.chat), style = MaterialTheme.typography.titleMedium,
                        color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        when {
                            conversation?.peerTyping == true -> stringResource(R.string.typing)
                            conversation?.peer?.online == true -> stringResource(R.string.online)
                            !conversation?.peer?.presence.isNullOrBlank() -> conversation?.peer?.presence.orEmpty()
                            else -> stringResource(R.string.local_contact)
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (conversation?.peerTyping == true || conversation?.peer?.online == true) p.accent else p.textMuted,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Box {
                IconButton(onClick = { menu = true }, enabled = conversation != null) {
                    Icon(Icons.Filled.MoreVert, stringResource(R.string.more), tint = p.text)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.contact_info)) }, onClick = { menu = false; profile = true })
                    DropdownMenuItem(text = { Text(stringResource(if (conversation?.muted == true) R.string.unmute else R.string.mute)) },
                        onClick = { menu = false; viewModel.toggleMuted() })
                }
            }
        }
        // The current repository has local persistence, not an integrated message transport.
        Text(stringResource(R.string.local_chat_notice), color = p.textMuted, style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.fillMaxWidth().background(p.surfaceAlt).padding(horizontal = 16.dp, vertical = 5.dp))

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val bubbleWidth = (maxWidth - ChatMetrics.oppositeGutter - ChatMetrics.listGutter * 2).coerceIn(80.dp, 520.dp)
            when {
                !loaded -> CircularProgressIndicator(Modifier.align(Alignment.Center).size(28.dp), strokeWidth = 2.dp)
                conversation == null -> Text(stringResource(R.string.chat_not_found), color = p.textMuted, modifier = Modifier.align(Alignment.Center))
                messages.isEmpty() -> Text(stringResource(R.string.no_messages), color = p.textMuted, modifier = Modifier.align(Alignment.Center))
                else -> LazyColumn(
                    state = list, reverseLayout = true,
                    modifier = Modifier.fillMaxSize().alpha(if (positioned) 1f else 0f),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 6.dp),
                ) {
                    items(rows, key = { it.key }, contentType = {
                        when (it) { is TimelineRow.Day -> "day"; is TimelineRow.Unread -> "unread"; is TimelineRow.Message -> "message" }
                    }) { row ->
                        when (row) {
                            is TimelineRow.Day -> DaySeparator(dayLabel(row.timeMillis, stringResource(R.string.today), stringResource(R.string.yesterday)))
                            is TimelineRow.Unread -> UnreadSeparator()
                            is TimelineRow.Message -> byId[row.id]?.let { message ->
                                MessageBubble(
                                    message, row, bubbleWidth,
                                    onLongPress = { selectedMessage = message },
                                    onRetry = { viewModel.retry(message.id) },
                                    modifier = Modifier.animateItem(
                                        fadeInSpec = if (positioned && initialIds != null && row.id !in initialIds.orEmpty()) tween(180) else null,
                                        placementSpec = tween(ChatMetrics.motionMillis, easing = ChatMetrics.motionEasing),
                                        fadeOutSpec = tween(120),
                                    ).padding(horizontal = ChatMetrics.listGutter),
                                )
                            }
                        }
                    }
                }
            }
            AnimatedVisibility(
                visible = positioned && !atBottom && messages.isNotEmpty(),
                enter = fadeIn(tween(150)), exit = fadeOut(tween(100)),
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if ((conversation?.unread ?: 0) > 0) {
                        Text("${conversation?.unread}", color = p.accentInk, style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.clip(CircleShape).background(p.accent).padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                    FilledIconButton(onClick = { scope.launch { list.animateScrollToItem(0); followLatest = true } },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = p.surface, contentColor = p.text),
                        modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Filled.KeyboardArrowDown, stringResource(R.string.jump_latest))
                    }
                }
            }
        }
        MessageComposer(draft, viewModel::onDraftChange, { viewModel.send() }, sendOnEnter, enabled = loaded && conversation != null)
    }

    if (profile && conversation != null) {
        ModalBottomSheet(onDismissRequest = { profile = false }, containerColor = p.surface) {
            val peer = conversation!!.peer
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                NuvaAvatar(peer.displayName, seed = peer.id, size = 80.dp, imageUrl = peer.avatarUrl.takeIf { it.isNotBlank() })
                Spacer(Modifier.height(12.dp))
                Text(peer.displayName, style = MaterialTheme.typography.titleLarge, color = p.text)
                Text("@${peer.username}", color = p.accent, modifier = Modifier.clickable { clipboard.setText(AnnotatedString("@${peer.username}")) }.padding(12.dp))
                if (peer.bio.isNotBlank()) Text(peer.bio, color = p.textMuted, modifier = Modifier.padding(bottom = 12.dp))
            }
            NuvaRow(title = stringResource(if (conversation?.muted == true) R.string.unmute else R.string.mute),
                subtitle = stringResource(R.string.local_mute_notice), icon = Icons.Filled.NotificationsOff,
                onClick = viewModel::toggleMuted, showChevron = false)
            Text(stringResource(R.string.block_not_supported), style = MaterialTheme.typography.bodySmall, color = p.textMuted,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp))
            Spacer(Modifier.navigationBarsPadding().height(8.dp))
        }
    }
    selectedMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { selectedMessage = null },
            title = { Text(stringResource(R.string.message_actions)) },
            text = { Column {
                Text(message.text, maxLines = 8, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                if (message.mine) Text(deliveryLabel(message.delivery), style = MaterialTheme.typography.bodySmall)
            } },
            confirmButton = { TextButton(onClick = { clipboard.setText(AnnotatedString(message.text)); selectedMessage = null }) {
                Icon(Icons.Filled.ContentCopy, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.copy_text))
            } },
            dismissButton = { TextButton(onClick = { selectedMessage = null }) { Text(stringResource(R.string.close)) } },
        )
    }
    BackHandler(menu) { menu = false }
}

@Composable
private fun DaySeparator(label: String) {
    val p = NuvaTheme.palette
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = p.textMuted,
            modifier = Modifier.clip(CircleShape).background(p.surfaceAlt).padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

@Composable
private fun UnreadSeparator() {
    val p = NuvaTheme.palette
    Box(Modifier.fillMaxWidth().height(ChatMetrics.unreadRowHeight), contentAlignment = Alignment.Center) {
        Box(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(top = ChatMetrics.unreadStripeTop)
            .height(ChatMetrics.unreadStripeHeight).background(p.surface))
        Text(stringResource(R.string.unread_messages), color = p.accent,
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 14.sp, fontWeight = FontWeight.Medium),
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 32.dp))
        Icon(Icons.Filled.KeyboardArrowDown, null, tint = p.accent,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 10.dp).size(18.dp))
    }
}

@Composable
internal fun MessageComposer(value: String, onChange: (String) -> Unit, onSend: () -> Unit, sendOnEnter: Boolean, enabled: Boolean) {
    val p = NuvaTheme.palette
    val latestSend by rememberUpdatedState(onSend)
    Row(Modifier.fillMaxWidth().background(p.surface).padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.Bottom) {
        Box(Modifier.weight(1f).heightIn(min = 48.dp).padding(horizontal = 10.dp, vertical = 12.dp), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) Text(stringResource(R.string.message_hint), color = p.textMuted, style = MaterialTheme.typography.bodyLarge)
            BasicTextField(
                value, onChange, enabled = enabled,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = p.text, fontSize = 16.sp),
                cursorBrush = SolidColor(p.accent), maxLines = 6,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences,
                    imeAction = if (sendOnEnter) ImeAction.Send else ImeAction.Default),
                keyboardActions = KeyboardActions(onSend = { if (enabled && value.isNotBlank()) latestSend() }),
                modifier = Modifier.testTag("composer-input").fillMaxWidth().onPreviewKeyEvent {
                    if (sendOnEnter && it.key == Key.Enter && !it.isShiftPressed) {
                        if (it.type == KeyEventType.KeyUp && enabled && value.isNotBlank()) latestSend()
                        true
                    } else false
                },
            )
        }
        IconButton(onClick = onSend, enabled = enabled && value.isNotBlank(), modifier = Modifier.testTag("composer-send").size(48.dp)) {
            Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send), tint = if (value.isNotBlank() && enabled) p.accent else p.textFaint)
        }
    }
}
