package club.nuva.app.ui.chat

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import club.nuva.app.ui.chat.layout.ChatTimeline
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(
    private val conversationId: String,
    private val store: ChatDraftStore,
    private val savedState: SavedStateHandle = SavedStateHandle(),
) : ViewModel() {
    val conversation = store.conversations.map { list -> list.firstOrNull { it.id == conversationId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), store.conversation(conversationId))
    val loaded = store.loaded
    val draft: StateFlow<String> = savedState.getStateFlow("draft", "")
    private val _firstUnreadId = MutableStateFlow<String?>(savedState["firstUnreadId"])
    val firstUnreadId = _firstUnreadId.asStateFlow()
    private var unreadCaptured = savedState.get<Boolean>("unreadCaptured") ?: false

    private val _unreadReady = MutableStateFlow(unreadCaptured)
    val unreadReady = _unreadReady.asStateFlow()

    init {
        // Capture BEFORE clearing unread. Restoring from disk may finish after this VM is created.
        viewModelScope.launch {
            combine(store.conversations, store.loaded) { list, loaded ->
                if (loaded) list.firstOrNull { it.id == conversationId } else null
            }.collect { it?.let(::captureUnread) }
        }
    }

    private fun captureUnread(conversation: ChatDraftStore.Conversation) {
        if (unreadCaptured) return
        _firstUnreadId.value = ChatTimeline.firstUnread(
            conversation.messages.filterNot { it.mine }.map { it.id }, conversation.unread,
        )
        savedState["firstUnreadId"] = _firstUnreadId.value
        unreadCaptured = true
        savedState["unreadCaptured"] = true
        _unreadReady.value = true
    }

    fun onDraftChange(value: String) { savedState["draft"] = value }
    fun send(): Boolean {
        val text = draft.value.trim()
        if (text.isEmpty() || !store.loaded.value || store.conversation(conversationId) == null) return false
        store.send(conversationId, text)
        savedState["draft"] = ""
        return true
    }
    fun retry(messageId: String) = store.retry(conversationId, messageId)
    fun toggleMuted() = store.toggleMuted(conversationId)

    /** Called only while RESUMED, after the newest row is visible; never on construction. */
    fun onLatestVisible() {
        store.conversation(conversationId)?.let {
            captureUnread(it)
            if (it.unread > 0) store.markRead(conversationId)
        }
    }
}
