package club.nuva.app.ui.chat

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import club.nuva.app.ui.preview.LocalPreviewSession
import club.nuva.app.R
import club.nuva.app.data.remote.RealtimeClient
import club.nuva.app.ui.design.NuvaAvatar
import club.nuva.app.ui.theme.NuvaTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ChatsViewModel(private val store: ChatDraftStore) : ViewModel() {

    data class UiState(
        val query: String = "",
        val conversations: List<ChatDraftStore.Conversation> = emptyList(),
        val totalUnread: Int = 0,
        val loaded: Boolean = false,
    )

    private val query = MutableStateFlow("")

    val state: StateFlow<UiState> = combine(store.conversations, query, store.loaded) { list, q, loaded ->
        val filtered = if (q.isBlank()) {
            list
        } else {
            val needle = q.trim().lowercase(Locale.getDefault())
            list.filter { conversation ->
                conversation.peer.displayName.lowercase(Locale.getDefault()).contains(needle) ||
                    conversation.peer.username.lowercase(Locale.getDefault()).contains(needle) ||
                    conversation.lastMessage?.text.orEmpty().lowercase(Locale.getDefault()).contains(needle)
            }
        }
        UiState(
            query = q,
            conversations = filtered.sortedByDescending { it.lastMessage?.sentAtMillis ?: 0L },
            totalUnread = list.sumOf { it.unread },
            loaded = loaded,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    fun onQueryChange(value: String) = query.update { value }
}

@Composable
fun ChatsScreen(
    viewModel: ChatsViewModel,
    realtimeState: RealtimeClient.State,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
    modifier: Modifier = Modifier,
    bottomInset: Dp = 0.dp,
    onMenu: () -> Unit = {},
    compact: Boolean = false,
) {
    val p = NuvaTheme.palette
    val state by viewModel.state.collectAsStateWithLifecycle()
    var searching by rememberSaveable { mutableStateOf(false) }
    val searchFocus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    LaunchedEffect(searching) { if (searching) searchFocus.requestFocus() }
    fun closeSearch() { focusManager.clearFocus(); searching = false; viewModel.onQueryChange("") }
    BackHandler(searching) { closeSearch() }
    Box(modifier.fillMaxSize().background(p.canvas)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().height(56.dp).background(p.surface), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (searching) closeSearch() else onMenu() }) {
                    Icon(if (searching) Icons.AutoMirrored.Filled.ArrowBack else Icons.Filled.Menu,
                        stringResource(if (searching) R.string.back else R.string.open_menu), tint = p.text)
                }
                if (searching) {
                    Box(Modifier.weight(1f)) {
                        if (state.query.isEmpty()) Text(stringResource(R.string.search_chats), color = p.textMuted)
                        BasicTextField(state.query, viewModel::onQueryChange, singleLine = true,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(color = p.text),
                            cursorBrush = SolidColor(p.accent), modifier = Modifier.fillMaxWidth().focusRequester(searchFocus))
                    }
                    IconButton(onClick = { viewModel.onQueryChange("") }) {
                        Icon(Icons.Filled.Close, stringResource(R.string.search_clear), tint = p.textMuted)
                    }
                } else {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.chats), style = MaterialTheme.typography.titleLarge, color = p.text)
                        if (realtimeState != RealtimeClient.State.Online) {
                            Text(stringResource(if (LocalPreviewSession.current != null) R.string.preview_no_server else when (realtimeState) {
                                RealtimeClient.State.Idle -> R.string.offline
                                RealtimeClient.State.Reconnecting -> R.string.reconnecting
                                else -> R.string.connecting
                            }), style = MaterialTheme.typography.bodySmall, color = p.textMuted)
                        }
                    }
                    IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, stringResource(R.string.search_chats), tint = p.text) }
                }
            }
            when {
                !state.loaded -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 2.dp)
                }
                state.conversations.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(if (state.query.isBlank()) R.string.no_chats else R.string.no_results),
                            color = p.text, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(stringResource(if (state.query.isBlank()) R.string.start_chat_hint else R.string.search_hint), color = p.textMuted)
                    }
                }
                else -> LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = bottomInset + 88.dp),
                ) {
                    items(state.conversations, key = { it.id }, contentType = { "conversation" }) { conversation ->
                        ConversationRow(conversation, compact, { onOpenChat(conversation.id) },
                            Modifier.animateItem(fadeInSpec = null, placementSpec = tween(250), fadeOutSpec = tween(120)))
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = onNewChat, containerColor = p.accent, contentColor = p.accentInk,
            shape = androidx.compose.foundation.shape.CircleShape,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = bottomInset + 16.dp).size(56.dp),
        ) { Icon(Icons.Filled.Edit, stringResource(R.string.new_chat)) }
    }
}

@Composable
private fun ConversationRow(conversation: ChatDraftStore.Conversation, compact: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val p = NuvaTheme.palette
    val last = conversation.lastMessage
    val unread = conversation.unread
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).heightIn(min = if (compact) 64.dp else 76.dp)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NuvaAvatar(conversation.peer.displayName, seed = conversation.peer.id,
                size = if (compact) 48.dp else 54.dp, imageUrl = conversation.peer.avatarUrl.takeIf { it.isNotBlank() }, online = conversation.peer.online)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(conversation.peer.displayName, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (conversation.muted) Icon(Icons.Filled.NotificationsOff, stringResource(R.string.mute), tint = p.textMuted, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(last?.let { relativeStamp(it.sentAtMillis) }.orEmpty(), color = if (unread > 0) p.accent else p.textMuted,
                        style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (last?.mine == true && !conversation.peerTyping) {
                        DeliveryTicks(last.delivery); Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        if (conversation.peerTyping) stringResource(R.string.typing) else last?.text ?: stringResource(R.string.no_messages),
                        color = if (conversation.peerTyping) p.accent else p.textMuted,
                        style = MaterialTheme.typography.bodyMedium, fontSize = 15.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    )
                    if (unread > 0) {
                        Spacer(Modifier.width(8.dp))
                        Badge(containerColor = if (conversation.muted) p.textMuted else p.accent, contentColor = p.accentInk) {
                            Text(if (unread > 999) "999+" else "$unread", modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                        }
                    }
                }
            }
        }
        HorizontalDivider(Modifier.padding(start = if (compact) 72.dp else 78.dp), thickness = 0.5.dp, color = p.hairline)
    }
}

private fun relativeStamp(millis: Long): String {
    val today = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = millis }
    return if (today.get(Calendar.YEAR) == date.get(Calendar.YEAR) && today.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR))
        clockLabel(millis) else DateFormat.getDateInstance(DateFormat.SHORT).format(Date(millis))
}
