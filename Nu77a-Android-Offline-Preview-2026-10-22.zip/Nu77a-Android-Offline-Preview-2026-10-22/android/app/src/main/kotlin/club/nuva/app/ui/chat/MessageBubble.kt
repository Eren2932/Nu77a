package club.nuva.app.ui.chat

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.constrainWidth
import androidx.compose.ui.unit.constrainHeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import club.nuva.app.R
import club.nuva.app.ui.chat.layout.BubbleGeometry
import club.nuva.app.ui.chat.layout.TimelineRow
import club.nuva.app.ui.theme.NuvaTheme
import kotlin.math.ceil

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun MessageBubble(
    message: ChatDraftStore.Message,
    row: TimelineRow.Message,
    maxWidth: Dp,
    onLongPress: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = NuvaTheme.palette
    val haptics = LocalHapticFeedback.current
    val mine = message.mine
    val shape = BubbleShape(mine, row.joinedAbove, row.joinedBelow)
    Box(
        modifier = modifier.fillMaxWidth().padding(
            top = if (row.joinedAbove) ChatMetrics.joinedGap else ChatMetrics.groupGap,
        ),
        contentAlignment = if (mine) AbsoluteAlignment.CenterRight else AbsoluteAlignment.CenterLeft,
    ) {
        val description = deliveryLabel(message.delivery)
        MeasuredBubbleContent(
            message = message,
            foreground = if (mine) p.bubbleOutText else p.bubbleInText,
            modifier = Modifier.testTag("bubble:${message.id}").widthIn(max = maxWidth)
                .clip(shape)
                .background(if (mine) p.bubbleOut else p.bubbleIn)
                .semantics(mergeDescendants = true) { if (mine) stateDescription = description }
                .combinedClickable(
                    onClick = { if (message.delivery == ChatDraftStore.Delivery.Failed) onRetry() },
                    onLongClickLabel = stringResource(R.string.message_actions),
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        onLongPress()
                    },
                ),
        )
    }
}

/**
 * Measure metadata and actual shaped text once per layout pass. Short messages use one line;
 * long last lines allocate a metadata row. RTL uses a separate row, avoiding bidi collisions.
 * No mutable onTextLayout -> recomposition -> measure feedback loop.
 */
@Composable
private fun MeasuredBubbleContent(message: ChatDraftStore.Message, foreground: Color, modifier: Modifier) {
    val textMeasurer = rememberTextMeasurer(cacheSize = 4)
    val style = MaterialTheme.typography.bodyLarge.copy(
        fontSize = 16.sp,
        lineHeight = 21.sp,
        fontWeight = FontWeight.Normal,
        letterSpacing = 0.sp,
        platformStyle = PlatformTextStyle(includeFontPadding = false),
        textDirection = TextDirection.Content,
    )
    val hasRtl = message.text.any {
        Character.getDirectionality(it) in setOf(
            Character.DIRECTIONALITY_RIGHT_TO_LEFT,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_EMBEDDING,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_OVERRIDE,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_ISOLATE,
        )
    }
    Layout(
        modifier = modifier,
        content = {
            Text(message.text, style = style, color = foreground, modifier = Modifier.testTag("body:${message.id}"))
            Row(Modifier.testTag("metadata:${message.id}"), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    clockLabel(message.sentAtMillis),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false),
                    ),
                    color = foreground.copy(alpha = 0.65f),
                )
                if (message.mine) {
                    Spacer(Modifier.width(3.dp))
                    DeliveryTicks(message.delivery, onLight = true)
                }
            }
        },
    ) { measurables, constraints ->
        val horizontal = ChatMetrics.horizontalPadding.roundToPx()
        val vertical = ChatMetrics.verticalPadding.roundToPx()
        val tail = ChatMetrics.tailWidth.roundToPx()
        val textLeft = horizontal + if (message.mine) 0 else tail
        val available = (constraints.maxWidth - horizontal * 2 - tail).coerceAtLeast(1)
        val childConstraints = Constraints(maxWidth = available)
        val meta = measurables[1].measure(childConstraints)
        val textLayout = textMeasurer.measure(text = message.text, style = style, constraints = childConstraints)
        val body = measurables[0].measure(childConstraints)
        val placement = BubbleGeometry.place(
            maxWidth = available,
            textWidth = body.width,
            textHeight = body.height,
            lastLineRight = ceil(textLayout.getLineRight((textLayout.lineCount - 1).coerceAtLeast(0))).toInt().coerceAtLeast(0),
            metaWidth = meta.width,
            metaHeight = meta.height,
            gap = ChatMetrics.metadataGap.roundToPx(),
            forceNewLine = hasRtl,
        )
        layout(
            constraints.constrainWidth(placement.width + horizontal * 2 + tail),
            constraints.constrainHeight(placement.height + vertical * 2),
        ) {
            body.place(textLeft, vertical)
            meta.place(textLeft + placement.metaX, vertical + placement.metaY)
        }
    }
}

@Composable
internal fun deliveryLabel(delivery: ChatDraftStore.Delivery): String = stringResource(
    when (delivery) {
        ChatDraftStore.Delivery.Sending -> R.string.delivery_saving
        ChatDraftStore.Delivery.Sent -> R.string.delivery_local
        ChatDraftStore.Delivery.Delivered -> R.string.delivery_delivered
        ChatDraftStore.Delivery.Read -> R.string.delivery_read
        ChatDraftStore.Delivery.Failed -> R.string.delivery_failed
    },
)

/** Public signature retained for conversation previews. Sent is LOCAL, not a server receipt. */
@Composable
fun DeliveryTicks(delivery: ChatDraftStore.Delivery, onLight: Boolean = false, modifier: Modifier = Modifier) {
    val p = NuvaTheme.palette
    val tint = when (delivery) {
        ChatDraftStore.Delivery.Failed -> p.danger
        ChatDraftStore.Delivery.Read -> p.accentSoft
        else -> if (onLight) p.bubbleOutText.copy(alpha = 0.65f) else p.textMuted
    }
    val icon = when (delivery) {
        ChatDraftStore.Delivery.Sending -> Icons.Filled.Schedule
        ChatDraftStore.Delivery.Sent -> Icons.Filled.Check
        ChatDraftStore.Delivery.Delivered, ChatDraftStore.Delivery.Read -> Icons.Filled.DoneAll
        ChatDraftStore.Delivery.Failed -> Icons.Filled.ErrorOutline
    }
    Icon(icon, deliveryLabel(delivery), tint = tint, modifier = modifier.size(14.dp))
}
