package club.nuva.app.ui.chat

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import club.nuva.app.R
import club.nuva.app.ui.design.NuvaAvatar
import club.nuva.app.ui.design.NuvaField
import club.nuva.app.ui.design.NuvaHeader
import club.nuva.app.ui.theme.NuvaTheme
import java.util.Locale

@Composable
fun NewChatScreen(
    store: ChatDraftStore,
    onOpenConversation: (String) -> Unit,
    modifier: Modifier = Modifier,
    bottomInset: Dp = 0.dp,
    onBack: (() -> Unit)? = null,
) {
    val p = NuvaTheme.palette
    val people by store.people.collectAsStateWithLifecycle()
    val loaded by store.loaded.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    val typed = query.trim().removePrefix("@").lowercase(Locale.ROOT)
    val matches = remember(people, typed) {
        people.filter { typed.isEmpty() || it.username.lowercase(Locale.ROOT).contains(typed) || it.displayName.lowercase(Locale.ROOT).contains(typed) }
    }
    val canCreate = loaded && typed.isNotEmpty() && typed.length <= 32 && people.none { it.username == typed } &&
        typed.all { it.isLetterOrDigit() || it == '_' || it == '.' }
    Column(modifier.fillMaxSize()) {
        NuvaHeader(stringResource(R.string.contacts), subtitle = stringResource(R.string.local_contacts), onBack = onBack)
        NuvaField(query, { query = it }, stringResource(R.string.find_contact),
            leadingIcon = Icons.Filled.PersonSearch, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = bottomInset + 16.dp)) {
            if (canCreate) {
                item(key = "create") {
                    TextButton(onClick = {
                        val person = store.createContact(typed)
                        onOpenConversation(store.openWith(person))
                    }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                        Text(stringResource(R.string.start_with, typed))
                    }
                    Text(stringResource(R.string.local_contact_notice), style = MaterialTheme.typography.bodySmall, color = p.textMuted,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                }
            }
            items(matches, key = { "person:${it.id}" }) { person ->
                Row(Modifier.fillMaxWidth().clickable(enabled = loaded) { onOpenConversation(store.openWith(person)) }
                    .heightIn(min = 64.dp).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    NuvaAvatar(person.displayName, seed = person.id, size = 46.dp, imageUrl = person.avatarUrl.takeIf { it.isNotBlank() })
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(person.displayName, color = p.text, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("@${person.username}", color = p.textMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider(Modifier.padding(start = 76.dp), thickness = 0.5.dp, color = p.hairline)
            }
            if (matches.isEmpty() && !canCreate) item(key = "empty") {
                Text(stringResource(R.string.no_contacts), color = p.textMuted, modifier = Modifier.padding(24.dp))
            }
        }
    }
}
