package club.nuva.app.ui.chat.layout

/** Physical pixels, after dp/sp conversion. No font-width estimates or magic character counts. */
object BubbleGeometry {
    data class Placement(val width: Int, val height: Int, val metaX: Int, val metaY: Int, val inline: Boolean)

    fun place(
        maxWidth: Int,
        textWidth: Int,
        textHeight: Int,
        lastLineRight: Int,
        metaWidth: Int,
        metaHeight: Int,
        gap: Int,
        forceNewLine: Boolean = false,
    ): Placement {
        require(maxWidth > 0)
        require(listOf(textWidth, textHeight, lastLineRight, metaWidth, metaHeight, gap).all { it >= 0 })
        val inline = !forceNewLine && lastLineRight.toLong() + gap + metaWidth <= maxWidth
        val width = maxOf(textWidth, metaWidth, if (inline) lastLineRight + gap + metaWidth else 0)
            .coerceIn(1, maxWidth)
        val height = if (inline) maxOf(textHeight, metaHeight) else textHeight + metaHeight
        return Placement(width, height, (width - metaWidth).coerceAtLeast(0), height - metaHeight, inline)
    }
}
