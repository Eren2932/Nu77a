package club.nuva.app.ui.chat.layout

import java.util.Calendar
import java.util.TimeZone

/** UI-independent timeline. Input is chronological; ties retain input order. */
data class TimelineMessage(val id: String, val authorId: String, val timeMillis: Long)

sealed interface TimelineRow {
    val key: String
    data class Day(val timeMillis: Long, override val key: String) : TimelineRow
    data class Unread(val firstMessageId: String) : TimelineRow {
        override val key = "unread:$firstMessageId"
    }
    data class Message(val id: String, val joinedAbove: Boolean, val joinedBelow: Boolean) : TimelineRow {
        override val key = "message:$id"
    }
}

object ChatTimeline {
    const val GROUP_WINDOW_MS = 300_000L

    /** Newest first, for LazyColumn(reverseLayout = true). Separators break groups. */
    fun build(
        messages: List<TimelineMessage>,
        firstUnreadId: String? = null,
        timeZone: TimeZone = TimeZone.getDefault(),
    ): List<TimelineRow> {
        val ordered = messages.sortedBy { it.timeMillis }
        val calendar = Calendar.getInstance(timeZone)
        fun day(time: Long): String {
            calendar.timeInMillis = time
            return "${calendar.get(Calendar.ERA)}:${calendar.get(Calendar.YEAR)}:${calendar.get(Calendar.DAY_OF_YEAR)}"
        }
        val days = ordered.map { day(it.timeMillis) }
        fun joined(before: Int, after: Int): Boolean {
            if (before < 0 || after >= ordered.size) return false
            val a = ordered[before]
            val b = ordered[after]
            return a.authorId == b.authorId && days[before] == days[after] &&
                b.id != firstUnreadId && b.timeMillis - a.timeMillis in 0..GROUP_WINDOW_MS
        }
        val rows = ArrayList<TimelineRow>(ordered.size + 8)
        ordered.forEachIndexed { index, message ->
            if (index == 0 || days[index - 1] != days[index]) {
                rows += TimelineRow.Day(message.timeMillis, "day:${days[index]}")
            }
            if (message.id == firstUnreadId) rows += TimelineRow.Unread(message.id)
            rows += TimelineRow.Message(message.id, joined(index - 1, index), joined(index, index + 1))
        }
        return rows.asReversed()
    }

    /** Count incoming messages only: outgoing entries may be interleaved. */
    fun firstUnread(incomingIds: List<String>, unreadCount: Int): String? =
        if (unreadCount <= 0) null else incomingIds.getOrNull((incomingIds.size - unreadCount).coerceAtLeast(0))
}
