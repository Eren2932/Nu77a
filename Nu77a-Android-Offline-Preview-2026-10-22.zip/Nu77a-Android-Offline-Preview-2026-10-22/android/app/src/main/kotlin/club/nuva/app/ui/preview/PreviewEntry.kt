package club.nuva.app.ui.preview

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import club.nuva.app.R
import club.nuva.app.ui.design.NuvaGhostButton
import club.nuva.app.ui.theme.NuvaTheme

@Composable
fun PreviewEntry(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth()) {
        NuvaGhostButton(stringResource(R.string.preview_skip), onClick,
            modifier = Modifier.testTag("preview-enter"))
        Text(stringResource(R.string.preview_entry_hint),
            style = MaterialTheme.typography.bodySmall, color = NuvaTheme.palette.textMuted,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
    }
}
