package club.nuva.app.ui.preview

/** Deterministic, explicitly fictional UI samples. No credentials or URLs. */
internal object PreviewFixtures {
    data class Message(val id: String, val mine: Boolean, val text: String, val time: Long)
    data class Chat(
        val id: String, val name: String, val username: String,
        val messages: List<Message>, val unread: Int = 0, val muted: Boolean = false,
    )

    fun chats(now: Long): List<Chat> {
        val minute = 60_000L
        fun message(id: String, mine: Boolean, text: String, minutesAgo: Int) =
            Message(id, mine, text, now - minutesAgo * minute)
        return listOf(
            Chat("preview-design", "Дизайн Nu77a", "demo_design", listOf(
                message("design-1", false, "Это тестовый диалог для просмотра интерфейса. Сервер не нужен.", 1500),
                message("design-2", true, "Привет! Проверяю обновление.", 1499),
                message("design-3", false, "Короткое", 12),
                message("design-4", false, "А это длинное сообщение: проверь переносы, ширину пузыря, отступы и положение времени. Можно менять тему и размер шрифта в настройках телефона.", 11),
                message("design-5", true, "Первая строка\nВторая строка\nТретья строка", 10),
                message("design-6", true, "🙂 🚀 ❤️", 9),
                message("design-7", false, "Открой карточку собеседника нажатием на заголовок чата.", 2),
                message("design-8", false, "Все персонажи и сообщения здесь вымышленные.", 1),
            ), unread = 2),
            Chat("preview-layout", "Проверка текста", "demo_text", listOf(
                message("layout-1", false, "л", 30),
                message("layout-2", true, "1234567890", 29),
                message("layout-3", false, "مرحبا بالعالم", 28),
                message("layout-4", true, "ОченьДлинноеСловоБезПробеловДляПроверкиПереносовОченьДлинноеСловоБезПробелов", 27),
                message("layout-5", false, "Кириллица, English, emoji 👨‍👩‍👧‍👦 — всё в одном пузыре.", 26),
            ), muted = true),
            Chat("preview-notes", "Тестовые заметки", "demo_notes", listOf(
                message("notes-1", false, "Можно отправлять свои сообщения: они останутся только в памяти этого деморежима и исчезнут после завершения процесса приложения.", 60),
                message("notes-2", true, "Это образец исходящего сообщения, а не подтверждение доставки.", 59),
            )),
            Chat("preview-empty", "Новый контакт", "demo_empty", emptyList()),
        )
    }
}
