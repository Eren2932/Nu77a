package club.nuva.app.ui.preview

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import club.nuva.app.data.local.ChatDatabase
import club.nuva.app.ui.chat.ChatDraftStore
import kotlinx.coroutines.CoroutineScope

/** App-process lifetime; a null SQLite name means an isolated IN-MEMORY database. */
class PreviewSession(context: Context, scope: CoroutineScope) {
    val userId = "preview-user"
    val username = "design_preview"
    var displayName by mutableStateOf("Просмотр дизайна")
        private set
    var bio by mutableStateOf("Тестовый профиль · без подключения к серверу")
        private set

    private val database = ChatDatabase(context, name = null)
    val chats = ChatDraftStore(database, scope) { db ->
        val sql = db.writableDatabase
        sql.beginTransaction()
        try {
            PreviewFixtures.chats(System.currentTimeMillis()).forEach { chat ->
                val peerId = "${chat.id}-peer"
                db.upsertPerson(ChatDatabase.PersonRow(peerId, chat.username, chat.name,
                    "Вымышленный контакт для проверки дизайна", ""))
                db.upsertConversation(ChatDatabase.ConversationRow(chat.id, peerId,
                    chat.unread, chat.muted, chat.messages.firstOrNull()?.time ?: 0L))
                chat.messages.forEach { message ->
                    db.insertMessage(ChatDatabase.MessageRow(message.id, chat.id,
                        if (message.mine) ChatDraftStore.ME_ID else peerId,
                        message.text, message.time, ChatDraftStore.Delivery.Sent.name))
                }
            }
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
    }

    fun updateProfile(name: String, about: String) {
        require(name.isNotBlank() && name.length <= 64 && about.length <= 280)
        displayName = name.trim()
        bio = about
    }
}

val LocalPreviewSession = staticCompositionLocalOf<PreviewSession?> { null }
