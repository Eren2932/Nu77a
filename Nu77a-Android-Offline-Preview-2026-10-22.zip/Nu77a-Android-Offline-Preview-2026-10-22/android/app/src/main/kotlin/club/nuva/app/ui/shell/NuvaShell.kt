package club.nuva.app.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import club.nuva.app.R
import club.nuva.app.di.ServiceLocator
import club.nuva.app.ui.chat.*
import club.nuva.app.ui.preview.LocalPreviewSession
import club.nuva.app.ui.home.PreviewDiagnosticsScreen
import club.nuva.app.data.remote.RealtimeClient
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.testTag
import club.nuva.app.ui.design.NuvaAvatar
import club.nuva.app.ui.home.DiagnosticsScreen
import club.nuva.app.ui.home.HomeViewModel
import club.nuva.app.ui.profile.EditProfileScreen
import club.nuva.app.ui.profile.ProfileScreen
import club.nuva.app.ui.settings.SettingsScreen
import club.nuva.app.ui.theme.NuvaTheme
import kotlinx.coroutines.launch

object Routes {
    const val CHATS = "chats"
    const val CHAT = "chat/{conversationId}"
    const val NEW_CHAT = "new_chat"
    const val PROFILE = "profile"
    const val PROFILE_EDIT = "profile_edit"
    const val SETTINGS = "settings"
    const val DIAGNOSTICS = "diagnostics"
    fun chat(conversationId: String) = "chat/${android.net.Uri.encode(conversationId)}"
}

@Composable
fun NuvaShell(onSwitchServer: () -> Unit, onExitPreview: () -> Unit = {}) {
    val preview = LocalPreviewSession.current
    val chatStore = preview?.chats ?: ServiceLocator.chatDrafts
    val p = NuvaTheme.palette
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val realtime by ServiceLocator.realtime.state.collectAsStateWithLifecycle()
    val prefs by ServiceLocator.uiPrefs.state.collectAsStateWithLifecycle()
    val session by ServiceLocator.authRepository.session.collectAsStateWithLifecycle()
    val displayName = preview?.displayName ?: session?.displayName?.ifBlank { session?.username.orEmpty() } ?: "Nu77a"
    val username = preview?.username ?: session?.username.orEmpty()
    val userId = preview?.userId ?: session?.userId.orEmpty()
    BackHandler(preview != null && route == Routes.CHATS && !drawer.isOpen) { onExitPreview() }
    fun open(target: String) {
        scope.launch { drawer.close() }
        nav.navigate(target) { popUpTo(Routes.CHATS); launchSingleTop = true }
    }
    BackHandler(drawer.isOpen) { scope.launch { drawer.close() } }
    ModalNavigationDrawer(
        drawerState = drawer,
        gesturesEnabled = route == Routes.CHATS,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = p.surface, modifier = Modifier.width(300.dp)) {
                Column(Modifier.fillMaxWidth().background(p.surfaceAlt).padding(20.dp)) {
                    NuvaAvatar(displayName,
                        seed = userId, size = 64.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(displayName, style = MaterialTheme.typography.titleMedium, color = p.text)
                    Text("@$username", style = MaterialTheme.typography.bodySmall, color = p.textMuted)
                }
                Spacer(Modifier.height(8.dp))
                listOf(
                    Triple(Routes.CHATS, R.string.chats, Icons.Filled.ChatBubbleOutline),
                    Triple(Routes.NEW_CHAT, R.string.contacts, Icons.Filled.PersonSearch),
                    Triple(Routes.PROFILE, R.string.profile, Icons.Filled.Person),
                    Triple(Routes.SETTINGS, R.string.settings, Icons.Filled.Settings),
                ).forEach { (target, label, icon) ->
                    NavigationDrawerItem(label = { Text(stringResource(label)) }, selected = target == route,
                        onClick = { open(target) }, icon = { Icon(icon, null) }, modifier = Modifier.padding(horizontal = 8.dp).testTag("preview-route-$target"))
                }
            }
        },
    ) {
        // A single owner of system insets. Child headers do not add another status bar.
        Column(Modifier.fillMaxSize().background(p.surface).statusBarsPadding().navigationBarsPadding()) {
            if (preview != null) {
                Row(Modifier.fillMaxWidth().background(p.surfaceAlt).padding(start = 16.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.preview_banner), modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.labelMedium, color = p.textMuted)
                    TextButton(onClick = onExitPreview, modifier = Modifier.testTag("preview-exit")) {
                        Text(stringResource(R.string.preview_exit))
                    }
                }
            }
            NavHost(
                navController = nav, startDestination = Routes.CHATS,
                modifier = Modifier.weight(1f).fillMaxWidth().background(p.canvas),
                enterTransition = { slideInHorizontally(tween(250)) { it / 5 } + fadeIn(tween(180)) },
                exitTransition = { fadeOut(tween(120)) },
                popEnterTransition = { fadeIn(tween(180)) },
                popExitTransition = { slideOutHorizontally(tween(250)) { it / 5 } + fadeOut(tween(180)) },
            ) {
                composable(Routes.CHATS) {
                    val vm: ChatsViewModel = viewModel(factory = viewModelFactory { initializer { ChatsViewModel(chatStore) } })
                    ChatsScreen(vm, if (preview != null) RealtimeClient.State.Idle else realtime, { nav.navigate(Routes.chat(it)) }, { nav.navigate(Routes.NEW_CHAT) },
                        onMenu = { scope.launch { drawer.open() } }, compact = prefs.compactChats)
                }
                composable(Routes.CHAT, arguments = listOf(navArgument("conversationId") { type = NavType.StringType })) { chatEntry ->
                    val id = chatEntry.arguments?.getString("conversationId").orEmpty()
                    val vm: ChatViewModel = viewModel(key = "chat-$id", factory = viewModelFactory {
                        initializer { ChatViewModel(id, chatStore, createSavedStateHandle()) }
                    })
                    ChatScreen(vm, { nav.popBackStack() }, sendOnEnter = prefs.sendOnEnter)
                }
                composable(Routes.NEW_CHAT) {
                    NewChatScreen(chatStore, { nav.navigate(Routes.chat(it)) }, onBack = { nav.popBackStack() })
                }
                composable(Routes.PROFILE) {
                    ProfileScreen(onEdit = { nav.navigate(Routes.PROFILE_EDIT) }, onSettings = { nav.navigate(Routes.SETTINGS) },
                        onBack = { nav.popBackStack() }, onDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) },
                        onExitPreview = onExitPreview)
                }
                composable(Routes.PROFILE_EDIT) { EditProfileScreen(onBack = { nav.popBackStack() }) }
                composable(Routes.SETTINGS) {
                    SettingsScreen(onBack = { nav.popBackStack() }, onSwitchServer = onSwitchServer, onDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) })
                }
                composable(Routes.DIAGNOSTICS) {
                    if (preview != null) {
                        // Do not even construct the network-owning ViewModel in preview.
                        PreviewDiagnosticsScreen(onBack = { nav.popBackStack() })
                    } else {
                        val vm: HomeViewModel = viewModel(factory = viewModelFactory {
                            initializer { HomeViewModel(ServiceLocator.authRepository, ServiceLocator.api, ServiceLocator.realtime) }
                        })
                        DiagnosticsScreen(vm, onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
