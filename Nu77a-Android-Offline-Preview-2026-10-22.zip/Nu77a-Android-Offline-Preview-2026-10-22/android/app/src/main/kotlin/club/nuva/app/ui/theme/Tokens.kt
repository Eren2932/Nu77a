package club.nuva.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import club.nuva.app.R
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Nu77a messenger theme. Geometry and motion for chat live in ChatMetrics.kt. */

// ---------------------------------------------------------------------------
// Palette
// ---------------------------------------------------------------------------

/** Roles Material 3 has no slot for. Reached through `NuvaTheme.palette`. */
@Immutable
data class NuvaPalette(
    val isDark: Boolean,
    /** App background. Nothing is painted below this. */
    val canvas: Color,
    /** Cards, tab bar, top bar. One step up from the canvas. */
    val surface: Color,
    /** Input fields, incoming bubbles, pressed states. */
    val surfaceAlt: Color,
    /** Wells: search field, day chips, anything that should read as recessed. */
    val surfaceSunken: Color,
    /** 1dp separators. The only structural line in the app. */
    val hairline: Color,
    val text: Color,
    val textMuted: Color,
    val textFaint: Color,
    /** Actions: FAB, own bubbles, active tab, primary buttons. */
    val accent: Color,
    /** A legible lighter accent, safe as a FOREGROUND on dark surfaces. */
    val accentSoft: Color,
    /** Accent at low alpha, for FILLS behind icons and active tabs. */
    val accentWash: Color,
    /** Text and icons drawn on top of `accent`. */
    val accentInk: Color,
    /** Confirmed: online, delivered, verified key. */
    val mint: Color,
    /** In flight: sending, pending, needs attention but not broken. */
    val amber: Color,
    /** The system talking about itself: links, selection, archive, hints. */
    val iris: Color,
    /** Destructive and failed. */
    val danger: Color,
    /** Kept as the pre-3.0 name for `danger`. New code uses `danger`. */
    val coral: Color,
    /** Own messages. */
    val bubbleOut: Color,
    val bubbleOutText: Color,
    /** Messages from the other side. */
    val bubbleIn: Color,
    val bubbleInText: Color,
    /** Soft wash behind hero areas only. Never behind body text. */
    val glow: Color,

    // -- added in 4.0 -------------------------------------------------------
    // All defaulted, so any existing NuvaPalette(...) call site still compiles.

    /** Top of the outgoing-bubble gradient. Equals [bubbleOut] for a flat look. */
    val bubbleOutTop: Color = bubbleOut,
    /** Bottom of the outgoing-bubble gradient. */
    val bubbleOutBottom: Color = bubbleOut,
    /** Floating layers: context menus, reaction bars, sheets. Above [surface]. */
    val surfaceRaised: Color = surfaceAlt,
    /** Full-screen dim behind a focused message or a modal. */
    val scrim: Color = Color(0x99000000),
    /** Played portion of a voice waveform. */
    val waveActive: Color = accent,
    /** Unplayed portion of a voice waveform. */
    val waveIdle: Color = textFaint,
)

internal val DarkPalette = NuvaPalette(
    isDark = true,
    canvas = Color(0xFF0E1621),
    surface = Color(0xFF17212B),
    surfaceAlt = Color(0xFF202B36),
    surfaceSunken = Color(0xFF101923),
    hairline = Color(0xFF25313D),
    text = Color(0xFFF5F5F5),
    textMuted = Color(0xFF94A3B3),
    textFaint = Color(0xFF7D8B99),
    accent = Color(0xFF64B5EF),
    accentSoft = Color(0xFF86C8F5),
    accentWash = Color(0x2664B5EF),
    accentInk = Color(0xFFFFFFFF),
    mint = Color(0xFF70C477),
    amber = Color(0xFFF5BB5C),
    iris = Color(0xFF64B5EF),
    danger = Color(0xFFF17B7B),
    coral = Color(0xFFF17B7B),
    bubbleOut = Color(0xFF2B5278),
    bubbleOutText = Color(0xFFFFFFFF),
    bubbleIn = Color(0xFF182533),
    bubbleInText = Color(0xFFFFFFFF),
    glow = Color(0x00000000),
    bubbleOutTop = Color(0xFF2B5278),
    bubbleOutBottom = Color(0xFF2B5278),
    surfaceRaised = Color(0xFF213040),
    scrim = Color(0xB3040710),
    waveActive = Color(0xFFFFFFFF),
    waveIdle = Color(0x66FFFFFF),
)

/**
 * Light is warm paper, not an inverted dark theme. Inverting a cold dark
 * palette gives a blue-white that looks like a bug report; paper looks
 * deliberate. The accent darkens so that white ink on it clears 4.5:1.
 */
internal val LightPalette = NuvaPalette(
    isDark = false,
    canvas = Color(0xFFE8EEF2),
    surface = Color(0xFFFFFFFF),
    surfaceAlt = Color(0xFFF1F3F5),
    surfaceSunken = Color(0xFFE9EDF0),
    hairline = Color(0xFFE1E6EA),
    text = Color(0xFF182533),
    textMuted = Color(0xFF667887),
    textFaint = Color(0xFF718392),
    accent = Color(0xFF2481CC),
    accentSoft = Color(0xFF2481CC),
    accentWash = Color(0x1F2481CC),
    accentInk = Color(0xFFFFFFFF),
    mint = Color(0xFF4BAE4E),
    amber = Color(0xFFAF741B),
    iris = Color(0xFF2481CC),
    danger = Color(0xFFCE4747),
    coral = Color(0xFFCE4747),
    bubbleOut = Color(0xFFEFFDDE),
    bubbleOutText = Color(0xFF182533),
    bubbleIn = Color(0xFFFFFFFF),
    bubbleInText = Color(0xFF182533),
    glow = Color(0x00000000),
    bubbleOutTop = Color(0xFFEFFDDE),
    bubbleOutBottom = Color(0xFFEFFDDE),
    surfaceRaised = Color(0xFFFFFFFF),
    scrim = Color(0x66101828),
    waveActive = Color(0xFFFFFFFF),
    waveIdle = Color(0x73FFFFFF),
)

internal fun darkScheme(p: NuvaPalette) = darkColorScheme(
    primary = p.accent,
    onPrimary = p.accentInk,
    primaryContainer = p.accent,
    onPrimaryContainer = p.accentInk,
    inversePrimary = p.accentSoft,
    secondary = p.mint,
    onSecondary = p.accentInk,
    tertiary = p.iris,
    onTertiary = Color.White,
    background = p.canvas,
    onBackground = p.text,
    surface = p.surface,
    onSurface = p.text,
    surfaceVariant = p.surfaceAlt,
    onSurfaceVariant = p.textMuted,
    surfaceContainer = p.surfaceAlt,
    surfaceContainerHigh = p.surfaceAlt,
    surfaceContainerLow = p.surface,
    error = p.danger,
    onError = Color.White,
    errorContainer = p.danger.copy(alpha = 0.16f),
    onErrorContainer = p.danger,
    outline = p.hairline,
    outlineVariant = p.hairline,
    scrim = Color(0xCC04070A),
)

internal fun lightScheme(p: NuvaPalette) = lightColorScheme(
    primary = p.accent,
    onPrimary = p.accentInk,
    primaryContainer = p.accent,
    onPrimaryContainer = p.accentInk,
    inversePrimary = p.accentSoft,
    secondary = p.mint,
    onSecondary = Color.White,
    tertiary = p.iris,
    onTertiary = Color.White,
    background = p.canvas,
    onBackground = p.text,
    surface = p.surface,
    onSurface = p.text,
    surfaceVariant = p.surfaceAlt,
    onSurfaceVariant = p.textMuted,
    surfaceContainer = p.surfaceAlt,
    surfaceContainerHigh = p.surfaceAlt,
    surfaceContainerLow = p.surface,
    error = p.danger,
    onError = Color.White,
    errorContainer = p.danger.copy(alpha = 0.12f),
    onErrorContainer = p.danger,
    outline = p.hairline,
    outlineVariant = p.hairline,
    scrim = Color(0x99000000),
)

// ---------------------------------------------------------------------------
// Type
// ---------------------------------------------------------------------------

/** Bundled fonts keep geometry independent of vendor-replaced system fonts. */
val NuvaFontFamily: FontFamily = FontFamily(
    Font(R.font.roboto_regular, FontWeight.Normal),
    Font(R.font.roboto_medium, FontWeight.Medium),
    Font(R.font.roboto_medium, FontWeight.SemiBold),
    Font(R.font.roboto_bold, FontWeight.Bold),
)
val NuvaMonoFamily: FontFamily = FontFamily.Monospace

private val centeredLineHeight = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim = LineHeightStyle.Trim.None,
)

private fun sans(
    size: Int,
    weight: FontWeight,
    lineHeight: Int,
    tracking: Double = 0.0,
) = TextStyle(
    fontFamily = NuvaFontFamily,
    fontSize = size.sp,
    fontWeight = weight,
    lineHeight = lineHeight.sp,
    letterSpacing = tracking.sp,
    lineHeightStyle = centeredLineHeight,
    platformStyle = PlatformTextStyle(includeFontPadding = false),
)

/** Shared, bundled Roboto typography. The chat body is measured at 16sp. */
internal val NuvaTypography = Typography(
    displaySmall = sans(32, FontWeight.Bold, 38, -0.8),
    headlineLarge = sans(28, FontWeight.Bold, 34, -0.6),
    headlineMedium = sans(24, FontWeight.Bold, 30, -0.5),
    headlineSmall = sans(20, FontWeight.SemiBold, 26, -0.4),
    titleLarge = sans(20, FontWeight.SemiBold, 26, -0.4),
    titleMedium = sans(18, FontWeight.Medium, 23),
    titleSmall = sans(16, FontWeight.Medium, 22),
    bodyLarge = sans(16, FontWeight.Normal, 22),
    bodyMedium = sans(15, FontWeight.Normal, 20),
    bodySmall = sans(13, FontWeight.Normal, 18),
    labelLarge = sans(15, FontWeight.SemiBold, 20),
    labelMedium = sans(13, FontWeight.Medium, 17, 0.1),
    labelSmall = sans(12, FontWeight.Normal, 16),
)

/** For ids, fingerprints, addresses and recovery codes. Never for prose. */
val NuvaMonoStyle: TextStyle = TextStyle(
    fontFamily = NuvaMonoFamily,
    fontSize = 13.sp,
    fontWeight = FontWeight.Medium,
    lineHeight = 18.sp,
    letterSpacing = 0.2.sp,
)

// ---------------------------------------------------------------------------
// Shape
// ---------------------------------------------------------------------------

internal val NuvaShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

/** Corner radii by role. `chip` is a full pill at any height. */
object NuvaRadius {
    val chip = 999.dp
    val tile = 12.dp
    val field = 8.dp
    val card = 8.dp
    val bubble = 12.dp

    /**
     * The tail corner of the last bubble in a run. A 6dp corner where the
     * other three are 20dp reads as "this side is speaking" without drawing a
     * triangle that breaks on line wrap or on a bubble two pixels tall.
     */
    val bubbleTail = 6.dp
    val sheet = 28.dp
}

// ---------------------------------------------------------------------------
// Spacing and size
// ---------------------------------------------------------------------------

/** One spacing scale. Screens use these names, not raw numbers. */
object NuvaSpace {
    val hair = 2.dp
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 20.dp
    val xxl = 28.dp
    val huge = 40.dp

    /** Horizontal page gutter. Every screen uses exactly this. */
    val gutter = 16.dp
}

/**
 * Fixed heights and diameters. These are the numbers that decide whether the
 * app feels like a messenger or like a settings menu, so they are named and
 * reviewed rather than typed at each call site.
 */
object NuvaSize {
    val topBar = 56.dp
    val tabBar = 60.dp
    val fab = 56.dp

    /** Icon button: 40dp of paint inside a 44dp touch target. */
    val iconButton = 48.dp
    val touchMin = 48.dp

    val searchField = 42.dp
    val chatRow = 68.dp
    val chatRowCompact = 60.dp
    val personRow = 56.dp

    val avatarChat = 48.dp
    val avatarPerson = 40.dp
    val avatarTopBar = 36.dp
    val avatarProfile = 96.dp

    val pin = 56.dp
    val pinRow = 84.dp

    val composerMin = 48.dp
    val actionTile = 64.dp
    val iconTile = 32.dp
    val cover = 200.dp

    /** Widest a bubble may get, as a fraction of the list width. */
    const val BUBBLE_MAX_WIDTH = 0.78f

    /** Room the tab bar needs at the bottom of a scrolling list. */
    val tabBarInset = 88.dp
}

/** Motion, in one place so the whole app breathes at one rate. */
object NuvaMotion {
    const val FAST = 90
    const val NORMAL = 180
    const val SLOW = 260

    /** Pre-3.0 name, kept so older call sites keep compiling. */
    const val BASE = NORMAL

    const val SPRING_STIFFNESS = 400f
    const val SPRING_DAMPING = 0.85f

    // -- added in 4.0 -------------------------------------------------------

    /** A bubble landing in the list. Long enough to read, short enough to feel instant. */
    const val BUBBLE_IN = 250

    /** Reaction pop, check-mark flip, tiny state changes. */
    const val MICRO = 130

    /** Context menu / reaction bar opening over a dimmed chat. */
    const val OVERLAY = 200

    /** One waveform bar redraw while recording. Below this it looks like noise. */
    const val WAVE_TICK = 60

    /** Hold this long before a press becomes a voice recording. */
    const val RECORD_HOLD_MS = 220L

    /** Drag this far left to cancel a recording. */
    const val CANCEL_SLIDE_DP = 96f
}
