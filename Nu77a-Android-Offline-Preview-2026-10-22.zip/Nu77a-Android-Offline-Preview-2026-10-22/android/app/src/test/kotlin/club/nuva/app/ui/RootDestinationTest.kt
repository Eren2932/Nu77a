package club.nuva.app.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class RootDestinationTest {
    @Test fun all32CombinationsPreserveTheLiveGateAndAllowExplicitPreview() {
        val flags = listOf(false, true)
        for (preview in flags) for (welcome in flags) for (server in flags)
            for (session in flags) for (switching in flags) {
                val expected = if (preview) RootDestination.Preview else when {
                    !welcome && !session -> RootDestination.Welcome
                    !server || switching -> RootDestination.Server
                    session -> RootDestination.Home
                    else -> RootDestination.Auth
                }
                assertEquals("preview=$preview welcome=$welcome server=$server session=$session switching=$switching",
                    expected, rootDestination(preview, welcome, server, session, switching))
            }
    }
    @Test fun freshInstallCanSkipBothWelcomeAndServer() {
        assertEquals(RootDestination.Preview, rootDestination(true, false, false, false, false))
    }
    @Test fun failedServerDoesNotTrapPreview() {
        assertEquals(RootDestination.Preview, rootDestination(true, true, false, false, true))
    }
    @Test fun exitingWithoutAccountReturnsToServerSetup() {
        assertEquals(RootDestination.Server, rootDestination(false, true, false, false, false))
    }
    @Test fun exitingWithConfiguredServerReturnsToAuth() {
        assertEquals(RootDestination.Auth, rootDestination(false, true, true, false, false))
    }
    @Test fun existingAccountStillOpensNormally() {
        assertEquals(RootDestination.Home, rootDestination(false, false, true, true, false))
    }
}
