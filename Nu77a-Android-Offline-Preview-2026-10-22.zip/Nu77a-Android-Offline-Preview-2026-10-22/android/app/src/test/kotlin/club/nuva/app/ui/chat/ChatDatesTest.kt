package club.nuva.app.ui.chat

import org.junit.Assert.*
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class ChatDatesTest {
    private fun label(then: String, now: String, zone: String = "UTC"): String {
        val tz = TimeZone.getTimeZone(zone)
        val parser = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT).apply { timeZone = tz }
        return dayLabel(parser.parse(then)!!.time, "today", "yesterday", parser.parse(now)!!.time, tz, Locale.US)
    }
    @Test fun `today compares the calendar day not elapsed hours`() {
        assertEquals("today", label("2026-10-21 00:01", "2026-10-21 23:59"))
    }
    @Test fun `yesterday crosses year boundary`() {
        assertEquals("yesterday", label("2025-12-31 22:00", "2026-01-01 01:00"))
    }
    @Test fun `yesterday crosses leap day`() {
        assertEquals("yesterday", label("2024-02-29 22:00", "2024-03-01 01:00"))
    }
    @Test fun `spring daylight saving uses local date`() {
        assertEquals("yesterday", label("2026-03-08 00:01", "2026-03-09 00:01", "America/New_York"))
    }
    @Test fun `fall daylight saving handles twenty five hour day`() {
        assertEquals("yesterday", label("2026-11-01 00:01", "2026-11-02 00:01", "America/New_York"))
    }
    @Test fun `older day includes year`() {
        assertEquals("Oct 19, 2025", label("2025-10-19 00:01", "2026-10-21 00:01"))
    }
}
