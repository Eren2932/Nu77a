package club.nuva.app.ui.chat.layout

import org.junit.Assert.*
import org.junit.Test
import java.util.Random

class BubbleGeometryTest {
    @Test fun `short text and metadata share one row`() {
        assertEquals(BubbleGeometry.Placement(96, 21, 46, 7, true),
            BubbleGeometry.place(280, 40, 21, 40, 50, 14, 6))
    }
    @Test fun `exact fit remains inline`() {
        assertTrue(BubbleGeometry.place(280, 224, 21, 224, 50, 14, 6).inline)
    }
    @Test fun `one pixel overflow adds metadata row`() {
        val p = BubbleGeometry.place(280, 225, 21, 225, 50, 14, 6)
        assertFalse(p.inline)
        assertEquals(35, p.height)
        assertEquals(21, p.metaY)
    }
    @Test fun `short final line does not widen a longer earlier line`() {
        val p = BubbleGeometry.place(280, 270, 63, 100, 50, 14, 6)
        assertEquals(270, p.width)
        assertEquals(220, p.metaX)
        assertEquals(49, p.metaY)
        assertTrue(p.inline)
    }
    @Test fun `rtl forces a separate row`() {
        val p = BubbleGeometry.place(280, 100, 21, 100, 50, 14, 6, forceNewLine = true)
        assertFalse(p.inline)
        assertEquals(35, p.height)
    }
    @Test fun `metadata wider than body controls bubble width`() {
        val p = BubbleGeometry.place(280, 10, 21, 10, 50, 14, 6, forceNewLine = true)
        assertEquals(50, p.width)
        assertEquals(0, p.metaX)
    }
    @Test fun `trailing newline can use empty last line`() {
        val p = BubbleGeometry.place(280, 100, 42, 0, 50, 14, 6)
        assertTrue(p.inline)
        assertEquals(42, p.height)
    }
    @Test fun `large scaled metadata stays within the bubble`() {
        val p = BubbleGeometry.place(280, 40, 21, 40, 90, 28, 6)
        assertEquals(28, p.height)
        assertEquals(0, p.metaY)
    }
    @Test(expected = IllegalArgumentException::class) fun `zero available width is rejected`() {
        BubbleGeometry.place(0, 0, 0, 0, 0, 0, 0)
    }
    @Test(expected = IllegalArgumentException::class) fun `negative measurements are rejected`() {
        BubbleGeometry.place(280, -1, 21, 0, 50, 14, 6)
    }
    @Test fun `twenty thousand measured layouts do not overlap or escape bounds`() {
        val random = Random(77)
        repeat(20_000) {
            val max = 64 + random.nextInt(1024)
            val textWidth = 1 + random.nextInt(max)
            val lastRight = random.nextInt(textWidth + 1)
            val textHeight = 21 + random.nextInt(1000)
            val metaWidth = 1 + random.nextInt(max)
            val metaHeight = 10 + random.nextInt(30)
            val gap = random.nextInt(20)
            val rtl = random.nextBoolean()
            val p = BubbleGeometry.place(max, textWidth, textHeight, lastRight, metaWidth, metaHeight, gap, rtl)
            assertTrue(p.width in 1..max)
            assertTrue(p.width >= textWidth)
            assertTrue(p.metaX >= 0 && p.metaX + metaWidth <= p.width)
            assertTrue(p.metaY >= 0 && p.metaY + metaHeight <= p.height)
            if (p.inline) {
                assertFalse(rtl)
                assertTrue(p.metaX >= lastRight + gap)
                assertEquals(maxOf(textHeight, metaHeight), p.height)
            } else {
                assertEquals(textHeight, p.metaY)
            }
        }
    }
}
