package club.nuva.app.ui.chat.layout

import org.junit.Assert.*
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class ChatTimelineTest {
    private val utc = TimeZone.getTimeZone("UTC")
    private fun time(value: String): Long = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT)
        .apply { timeZone = utc }.parse(value)!!.time
    private val start = time("2026-10-21 12:00:00")
    private fun msg(id: String, offset: Long = 0L, author: String = "alice") = TimelineMessage(id, author, start + offset)
    private fun rows(vararg items: TimelineMessage) = ChatTimeline.build(items.toList(), timeZone = utc)
    private fun messages(rows: List<TimelineRow>) = rows.filterIsInstance<TimelineRow.Message>().asReversed()

    @Test fun `empty timeline has no separators`() { assertTrue(rows().isEmpty()) }
    @Test fun `single message follows one day separator chronologically`() {
        val r = rows(msg("a"))
        assertEquals(2, r.size)
        assertEquals(TimelineRow.Message("a", false, false), r.first())
        assertTrue(r.last() is TimelineRow.Day)
    }
    @Test fun `five minute boundary is inclusive`() {
        val r = messages(rows(msg("a"), msg("b", 300_000L)))
        assertTrue(r[0].joinedBelow)
        assertTrue(r[1].joinedAbove)
    }
    @Test fun `five minutes plus one millisecond breaks a run`() {
        val r = messages(rows(msg("a"), msg("b", 300_001L)))
        assertFalse(r[0].joinedBelow)
        assertFalse(r[1].joinedAbove)
    }
    @Test fun `different senders break a run even at the same timestamp`() {
        assertTrue(messages(rows(msg("a"), msg("b", author = "bob"))).all { !it.joinedAbove && !it.joinedBelow })
    }
    @Test fun `middle bubble joins both sides`() {
        val r = messages(rows(msg("a"), msg("b", 1), msg("c", 2)))
        assertEquals(TimelineRow.Message("b", true, true), r[1])
    }
    @Test fun `unread separator breaks both neighbouring joins`() {
        val r = ChatTimeline.build(listOf(msg("a"), msg("b", 1), msg("c", 2)), "b", utc).asReversed()
        assertEquals(5, r.size)
        assertEquals(TimelineRow.Unread("b"), r[2])
        assertEquals(TimelineRow.Message("a", false, false), r[1])
        assertEquals(TimelineRow.Message("b", false, true), r[3])
    }
    @Test fun `midnight produces a separate day and breaks joins`() {
        val r = rows(TimelineMessage("a", "alice", time("2026-10-21 23:59:59")), TimelineMessage("b", "alice", time("2026-10-22 00:00:00")))
        assertEquals(2, r.filterIsInstance<TimelineRow.Day>().size)
        assertTrue(messages(r).all { !it.joinedAbove && !it.joinedBelow })
    }
    @Test fun `day boundaries use the supplied timezone`() {
        val items = listOf(TimelineMessage("a", "alice", time("2026-10-21 20:59:59")), TimelineMessage("b", "alice", time("2026-10-21 21:00:00")))
        assertEquals(1, ChatTimeline.build(items, timeZone = utc).filterIsInstance<TimelineRow.Day>().size)
        assertEquals(2, ChatTimeline.build(items, timeZone = TimeZone.getTimeZone("Europe/Moscow")).filterIsInstance<TimelineRow.Day>().size)
    }
    @Test fun `ties retain input order and out of order timestamps are sorted`() {
        val r = messages(rows(msg("c", 2), msg("b", 1), msg("a", 1)))
        assertEquals(listOf("b", "a", "c"), r.map { it.id })
    }
    @Test fun `unread id outside loaded history does not manufacture a separator`() {
        assertTrue(ChatTimeline.build(listOf(msg("a")), "missing", utc).none { it is TimelineRow.Unread })
    }
    @Test fun `first unread uses incoming list and clamps oversized counts`() {
        assertNull(ChatTimeline.firstUnread(emptyList(), 1))
        assertNull(ChatTimeline.firstUnread(listOf("a"), 0))
        assertNull(ChatTimeline.firstUnread(listOf("a"), -1))
        assertEquals("b", ChatTimeline.firstUnread(listOf("a", "b", "c"), 2))
        assertEquals("a", ChatTimeline.firstUnread(listOf("a", "b"), 99))
    }
    @Test fun `keys of existing messages remain stable after prepend and append`() {
        val old = rows(msg("a", 1), msg("b", 2)).filterIsInstance<TimelineRow.Message>().map { it.key }.toSet()
        val new = rows(msg("older"), msg("a", 1), msg("b", 2), msg("newer", 3))
        assertTrue(new.map { it.key }.containsAll(old))
        assertEquals(new.size, new.map { it.key }.toSet().size)
    }
    @Test fun `ten thousand messages preserve order unique keys and symmetric joins`() {
        val items = (0 until 10_000).map { msg("id:$it", it * 60_000L, if (it % 3 == 0) "bob" else "alice") }
        val rows = ChatTimeline.build(items, "id:5000", utc)
        assertEquals(rows.size, rows.map { it.key }.toSet().size)
        val m = messages(rows)
        assertEquals(items.map { it.id }, m.map { it.id })
        m.zipWithNext().forEach { (a, b) -> assertEquals(a.joinedBelow, b.joinedAbove) }
    }
}
