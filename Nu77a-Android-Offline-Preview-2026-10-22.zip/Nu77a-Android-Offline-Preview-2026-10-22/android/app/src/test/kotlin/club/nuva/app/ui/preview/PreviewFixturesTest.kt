package club.nuva.app.ui.preview

import org.junit.Assert.*
import org.junit.Test

class PreviewFixturesTest {
    private val now = 1_792_627_200_000L
    private val chats = PreviewFixtures.chats(now)
    @Test fun idsAndUsernamesAreUnique() {
        assertEquals(chats.size, chats.map { it.id }.toSet().size)
        assertEquals(chats.size, chats.map { it.username }.toSet().size)
        val messages = chats.flatMap { it.messages }
        assertEquals(messages.size, messages.map { it.id }.toSet().size)
    }
    @Test fun timestampsAreOrderedAndNotInTheFuture() {
        chats.forEach { chat ->
            assertEquals(chat.messages.map { it.time }.sorted(), chat.messages.map { it.time })
            assertTrue(chat.messages.all { it.time <= now })
        }
    }
    @Test fun unreadCountsReferToIncomingSamples() {
        chats.forEach { assertTrue(it.unread >= 0 && it.unread <= it.messages.count { m -> !m.mine }) }
    }
    @Test fun samplesCoverEmptyMutedMultilineIncomingAndOutgoing() {
        assertTrue(chats.any { it.messages.isEmpty() })
        assertTrue(chats.any { it.muted })
        assertTrue(chats.flatMap { it.messages }.any { it.mine })
        assertTrue(chats.flatMap { it.messages }.any { !it.mine })
        assertTrue(chats.flatMap { it.messages }.any { it.text.contains('\n') })
    }
    @Test fun fixedClockProducesIdenticalData() {
        assertEquals(chats, PreviewFixtures.chats(now))
    }
}
