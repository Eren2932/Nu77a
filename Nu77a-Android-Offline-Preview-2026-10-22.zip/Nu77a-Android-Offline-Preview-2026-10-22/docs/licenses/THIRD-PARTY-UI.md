# Third-party UI assets

Bundled files: `android/app/src/main/res/font/roboto_regular.ttf`,
`roboto_medium.ttf`, `roboto_bold.ttf`.

Roboto. Copyright 2015 Google Inc. All Rights Reserved.
Licensed under the Apache License, Version 2.0.
The original copyright/license name-table entries remain embedded in each font.
Full license: `Roboto-Apache-2.0.txt` in this directory.
Upstream: https://github.com/googlefonts/roboto

The Telegram Android sources were inspected as reference material. Telegram
identifies its code as GPL v2 or later; no Telegram source classes, logos,
icons or drawable resources are shipped in this UI update. Reference links
and distinctions between observed values and independent adaptations are in
`../UI-REDESIGN.md`.

This notice does not choose or change the license of the Nu77a project.
The original archive does not contain a root project LICENSE file; any
project-wide licensing decision belongs to its author.
