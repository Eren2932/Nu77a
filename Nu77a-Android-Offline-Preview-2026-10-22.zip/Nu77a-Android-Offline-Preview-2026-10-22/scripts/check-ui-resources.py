#!/usr/bin/env python3
"""Static resource checks; Python 3.11+. Not a replacement for AAPT2/Android compilation."""
from pathlib import Path
import re
import tomllib
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent.parent
res = root / "android/app/src/main/res"
xmls = list(res.rglob("*.xml"))
for file in xmls:
    ET.parse(file)


def resources(folder):
    result = {}
    for file in (res / folder).glob("*.xml"):
        for element in ET.parse(file).getroot():
            key = (element.tag, element.get("name"))
            if key in result:
                raise ValueError(f"Duplicate resource {key} in {file}")
            result[key] = element
    return result


default = resources("values")
russian = resources("values-ru")
references = 0
for file in (root / "android/app/src").rglob("*.kt"):
    for name in re.findall(r"R\.string\.(\w+)", file.read_text()):
        if ("string", name) not in default:
            raise ValueError(f"Missing R.string.{name} in {file}")
        references += 1
for key, element in russian.items():
    if key not in default:
        raise ValueError(f"Translated resource lacks default: {key}")
    placeholders = lambda value: sorted(re.findall(r"%\d+\$\w", value or ""))
    if placeholders(element.text) != placeholders(default[key].text):
        raise ValueError(f"Mismatched format placeholders: {key}")

catalog = tomllib.loads((root / "android/gradle/libs.versions.toml").read_text())
aliases = {key.replace("-", ".") for key in catalog["libraries"]}
for file in (root / "android").rglob("*.gradle.kts"):
    for ref in re.findall(r"libs\.([a-z][\w.]+)", file.read_text()):
        if not ref.startswith("plugins.") and ref not in aliases:
            raise ValueError(f"Unknown library alias {ref} in {file}")
print(f"PASS: {len(xmls)} XML files; {len(russian)} translated resources; "
      f"{references} R.string references; version-catalog aliases")
