package club.nuva.app.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import club.nuva.app.R
import club.nuva.app.di.ServiceLocator
import club.nuva.app.ui.chat.*
import club.nuva.app.ui.design.NuvaAvatar
import club.nuva.app.ui.home.DiagnosticsScreen
import club.nuva.app.ui.home.HomeViewModel
import club.nuva.app.ui.profile.EditProfileScreen
import club.nuva.app.ui.profile.ProfileScreen
import club.nuva.app.ui.settings.SettingsScreen
import club.nuva.app.ui.theme.NuvaTheme
import kotlinx.coroutines.launch

object Routes {
    const val CHATS = "chats"
    const val CHAT = "chat/{conversationId}"
    const val NEW_CHAT = "new_chat"
    const val PROFILE = "profile"
    const val PROFILE_EDIT = "profile_edit"
    const val SETTINGS = "settings"
    const val DIAGNOSTICS = "diagnostics"
    fun chat(conversationId: String) = "chat/${android.net.Uri.encode(conversationId)}"
}

@Composable
fun NuvaShell(onSwitchServer: () -> Unit) {
    val p = NuvaTheme.palette
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val realtime by ServiceLocator.realtime.state.collectAsStateWithLifecycle()
    val prefs by ServiceLocator.uiPrefs.state.collectAsStateWithLifecycle()
    val session by ServiceLocator.authRepository.session.collectAsStateWithLifecycle()
    fun open(target: String) {
        scope.launch { drawer.close() }
        nav.navigate(target) { popUpTo(Routes.CHATS); launchSingleTop = true }
    }
    BackHandler(drawer.isOpen) { scope.launch { drawer.close() } }
    ModalNavigationDrawer(
        drawerState = drawer,
        gesturesEnabled = route == Routes.CHATS,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = p.surface, modifier = Modifier.width(300.dp)) {
                Column(Modifier.fillMaxWidth().background(p.surfaceAlt).padding(20.dp)) {
                    NuvaAvatar(session?.displayName?.ifBlank { session?.username.orEmpty() } ?: "Nu77a",
                        seed = session?.userId.orEmpty(), size = 64.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(session?.displayName?.ifBlank { session?.username.orEmpty() } ?: "Nu77a", style = MaterialTheme.typography.titleMedium, color = p.text)
                    Text("@${session?.username.orEmpty()}", style = MaterialTheme.typography.bodySmall, color = p.textMuted)
                }
                Spacer(Modifier.height(8.dp))
                listOf(
                    Triple(Routes.CHATS, R.string.chats, Icons.Filled.ChatBubbleOutline),
                    Triple(Routes.NEW_CHAT, R.string.contacts, Icons.Filled.PersonSearch),
                    Triple(Routes.PROFILE, R.string.profile, Icons.Filled.Person),
                    Triple(Routes.SETTINGS, R.string.settings, Icons.Filled.Settings),
                ).forEach { (target, label, icon) ->
                    NavigationDrawerItem(label = { Text(stringResource(label)) }, selected = target == route,
                        onClick = { open(target) }, icon = { Icon(icon, null) }, modifier = Modifier.padding(horizontal = 8.dp))
                }
            }
        },
    ) {
        // A single owner of system insets. Child headers do not add another status bar.
        Box(Modifier.fillMaxSize().background(p.surface).statusBarsPadding().navigationBarsPadding()) {
            NavHost(
                navController = nav, startDestination = Routes.CHATS,
                modifier = Modifier.fillMaxSize().background(p.canvas),
                enterTransition = { slideInHorizontally(tween(250)) { it / 5 } + fadeIn(tween(180)) },
                exitTransition = { fadeOut(tween(120)) },
                popEnterTransition = { fadeIn(tween(180)) },
                popExitTransition = { slideOutHorizontally(tween(250)) { it / 5 } + fadeOut(tween(180)) },
            ) {
                composable(Routes.CHATS) {
                    val vm: ChatsViewModel = viewModel(factory = viewModelFactory { initializer { ChatsViewModel(ServiceLocator.chatDrafts) } })
                    ChatsScreen(vm, realtime, { nav.navigate(Routes.chat(it)) }, { nav.navigate(Routes.NEW_CHAT) },
                        onMenu = { scope.launch { drawer.open() } }, compact = prefs.compactChats)
                }
                composable(Routes.CHAT, arguments = listOf(navArgument("conversationId") { type = NavType.StringType })) { chatEntry ->
                    val id = chatEntry.arguments?.getString("conversationId").orEmpty()
                    val vm: ChatViewModel = viewModel(key = "chat-$id", factory = viewModelFactory {
                        initializer { ChatViewModel(id, ServiceLocator.chatDrafts, createSavedStateHandle()) }
                    })
                    ChatScreen(vm, { nav.popBackStack() }, sendOnEnter = prefs.sendOnEnter)
                }
                composable(Routes.NEW_CHAT) {
                    NewChatScreen(ServiceLocator.chatDrafts, { nav.navigate(Routes.chat(it)) }, onBack = { nav.popBackStack() })
                }
                composable(Routes.PROFILE) {
                    ProfileScreen(onEdit = { nav.navigate(Routes.PROFILE_EDIT) }, onSettings = { nav.navigate(Routes.SETTINGS) },
                        onBack = { nav.popBackStack() }, onDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) })
                }
                composable(Routes.PROFILE_EDIT) { EditProfileScreen(onBack = { nav.popBackStack() }) }
                composable(Routes.SETTINGS) {
                    SettingsScreen(onBack = { nav.popBackStack() }, onSwitchServer = onSwitchServer, onDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) })
                }
                composable(Routes.DIAGNOSTICS) {
                    val vm: HomeViewModel = viewModel(factory = viewModelFactory {
                        initializer { HomeViewModel(ServiceLocator.authRepository, ServiceLocator.api, ServiceLocator.realtime) }
                    })
                    DiagnosticsScreen(vm, onBack = { nav.popBackStack() })
                }
            }
        }
    }
}
